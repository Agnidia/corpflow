#!/usr/bin/env bash
# @description dv-tree-preflight.sh — DV pre-edit assertion that the resolved tree IS
#   the assigned tree.
#
#   D0 records the git root and D0.0 asserts the tree is isolated. Neither compares the
#   resolved root against the workspace the stage was ASSIGNED. Isolation does not imply
#   assignment: a stale worktree satisfies both existing gates. This script asserts the
#   missing half and nothing else.
#
#   Checks, in order:
#     1. MISMATCH (blocking)  — `git rev-parse --show-toplevel` != the assigned workspace.
#     2. LINKAGE (advisory)   — the tree is not a linked worktree.
#     3. ANCESTRY (advisory)  — HEAD does not descend from the integration branch.
#   Only check 1 blocks. An input that does not resolve degrades to a warning: a
#   pre-flight that false-blocks DV is worse than the failure it guards against.
#
# @arg --assigned <path>  The workspace DV was dispatched against. When omitted, falls
#                         back to state.json `.metadata.workspace_path`, then to
#                         $WORKSPACE_ROOT. Unresolved ⇒ warn, never block.
# @arg --state <path>     state.json path (default: resolved via
#                         corpflow_context_dir(), never the invoking cwd).
# @arg --quiet            Suppress advisory warnings; a mismatch still prints and blocks.
# @arg --self-test        Run the built-in self-test and exit.
# @arg -h | --help        Show this header.
#
# @exitcode 0  Assigned tree confirmed (or inputs unresolved — warned, not blocked).
# @exitcode 1  MISMATCH: the resolved git root is not the assigned workspace. Do not edit.
# @exitcode 2  Usage error.
#
# Minimum shell: bash 3.2+ (macOS default).

set -euo pipefail
IFS=$'\n\t'

usage() {
  sed -n 's/^# \{0,1\}//p' "$0" | head -30
  exit 2
}

warn() { [[ -n "${QUIET:-}" ]] || printf >&2 'WARN: %s\n' "$1"; }

# Physical-path normalization. Load-bearing rather than defensive: /tmp is a symlink to
# /private/tmp on macOS, so a raw string compare calls two names for the same directory a
# mismatch and blocks DV in exactly the tmpdir the test suite runs in.
realpath_of() {
  local p="$1"
  [[ -z "$p" ]] && return 1
  (CDPATH= cd -- "$p" 2> /dev/null && pwd -P) || return 1
}

# Mirrors branch-name.sh is_host_workspace(), inverted: true when THIS tree is a linked
# worktree. Both dirs are resolved physically first — from a subdirectory git answers
# --git-dir absolutely and --git-common-dir relatively, and a raw compare then calls every
# nested cwd a worktree.
is_linked_worktree() {
  local d c
  d=$(git rev-parse --git-dir 2> /dev/null) || return 1
  c=$(git rev-parse --git-common-dir 2> /dev/null) || return 1
  [[ -n "$d" && -n "$c" ]] || return 1
  d=$(realpath_of "$d") || return 1
  c=$(realpath_of "$c") || return 1
  [[ "$d" != "$c" ]]
}

# Ranked resolution of the assigned workspace. metadata.workspace_path is a Task-System
# field that state.json is not schema-obliged to carry, so every rank may legitimately
# come back empty — hence the warn-not-block contract at the call site.
resolve_assigned() {
  local v="${ASSIGNED_ARG:-}"
  if [[ -z "$v" && -f "$STATE_PATH" ]] && command -v jq > /dev/null 2>&1; then
    v=$(jq -r '.metadata.workspace_path // empty' "$STATE_PATH" 2> /dev/null || printf '')
  fi
  [[ -z "$v" ]] && v="${WORKSPACE_ROOT:-}"
  [[ "$v" == "null" ]] && v=""
  printf '%s' "$v"
}

# Integration branch. A REDUCED copy of branch-lib.sh resolve_base_ref(): it omits rank 3
# (workspace.json .git.base_branch) and rank 0 (fork-point evidence), so a megatask
# per-issue base resolves here only via state.json. Shared invariants hold — no hardcoded
# literal, unresolved reported rather than guessed. Collapsing the three ladders onto the
# shared one is tracked as a follow-up; do not widen the divergence here.
resolve_base_ref() {
  local v="${FN_BASE_REF:-}"
  if [[ -z "$v" && -f "$STATE_PATH" ]] && command -v jq > /dev/null 2>&1; then
    v=$(jq -r '.metadata.base_ref // empty' "$STATE_PATH" 2> /dev/null || printf '')
  fi
  if [[ -z "$v" ]]; then
    v=$(git symbolic-ref --short refs/remotes/origin/HEAD 2> /dev/null || printf '')
  fi
  [[ "$v" == "null" ]] && v=""
  printf '%s' "$v"
}

cmd_check() {
  local root assigned assigned_real base

  root=$(git rev-parse --show-toplevel 2> /dev/null || printf '')
  if [[ -z "$root" ]]; then
    warn "not inside a git work tree — cannot verify the assigned tree; skipping"
    return 0
  fi
  # An unresolvable git root is an unresolved INPUT, not a mismatch. Blanking it here would
  # compare unequal below and block DV over an unrelated failure — the one outcome this
  # script's contract rules out.
  root=$(realpath_of "$root") || {
    warn "could not resolve the git root to a physical path — cannot compare; proceeding"
    return 0
  }

  assigned=$(resolve_assigned)
  if [[ -z "$assigned" ]]; then
    warn "assigned workspace unresolved (no --assigned, no state.json .metadata.workspace_path, no \$WORKSPACE_ROOT) — cannot compare; proceeding"
    return 0
  fi
  assigned_real=$(realpath_of "$assigned") || {
    warn "assigned workspace does not exist on disk: $assigned — cannot compare; proceeding"
    return 0
  }

  # 1. The blocking check. Naming BOTH paths is the whole point: the source failure was
  #    an agent that knew its tree and never learned it was the wrong one.
  if [[ "$root" != "$assigned_real" ]]; then
    printf >&2 'MISMATCH: DV resolved a different tree than it was assigned.\n  resolved git root: %s\n  assigned workspace: %s\nDo NOT edit. Re-enter the assigned tree (EnterWorktree with the assigned path) and re-run D0.\n' \
      "$root" "$assigned_real"
    return 1
  fi

  # 1a. Worktree-parent ambiguity. Advisory — this stream is provably on the right
  #     tree (check 1 passed), so blocking it would stop a correct stream over a
  #     condition that harms a DIFFERENT one. But it is reported loudly, because it
  #     is the latent cause of check 1 firing at all.
  #
  #     When linked worktrees live under more than one parent directory, anything
  #     that reconstructs a worktree path BY CONVENTION — rather than reading the
  #     task's own metadata.workspace_path — has to guess a prefix. It globs one,
  #     and gets another stream's directory. Observed cost in one four-stream run:
  #     a stream was assigned `.claude/worktrees/dv3-web` and handed
  #     `.worktrees/dv0-service` at spawn on four consecutive dispatches, because
  #     `.worktrees/` held exactly one entry for the glob to land on. Normalising
  #     to a single parent fixed it on the next dispatch.
  #
  #     Cheap to check, and it names the condition before four streams pay for it.
  local _main_common _main_checkout _wt_line _wt_path _wt_parent _parents _n_parents
  _main_common=$(git rev-parse --git-common-dir 2> /dev/null || printf '')
  _main_checkout=""
  if [[ -n "$_main_common" ]]; then
    _main_checkout=$(cd "$(dirname "$_main_common")" 2> /dev/null && pwd) || _main_checkout=""
  fi
  _parents=""
  while IFS= read -r _wt_line; do
    [[ "$_wt_line" == worktree\ * ]] || continue
    _wt_path="${_wt_line#worktree }"
    # The main checkout is not a linked worktree; its parent says nothing about
    # where linked worktrees are placed.
    [[ -n "$_main_checkout" && "$_wt_path" == "$_main_checkout" ]] && continue
    _wt_parent=$(dirname "$_wt_path")
    case "
$_parents" in
      *"
$_wt_parent"*) : ;;
      *) _parents="$_parents
$_wt_parent" ;;
    esac
  done < <(git worktree list --porcelain 2> /dev/null)
  _n_parents=$(printf '%s' "$_parents" | grep -c . || true)
  if [[ "${_n_parents:-0}" -gt 1 ]]; then
    printf >&2 'WARN: linked worktrees are split across %s parent directories:\n' "$_n_parents"
    printf '%s\n' "$_parents" | grep . | while IFS= read -r _wt_parent; do
      printf >&2 '  %s/\n' "$_wt_parent"
    done
    printf >&2 'A path rebuilt by convention instead of from metadata.workspace_path can resolve into the wrong parent and hand a stage another stream'"'"'s tree. Normalise every stage worktree under ONE parent (%s is where EnterWorktree can reach).\n' \
      "${_main_checkout:+$_main_checkout/}.claude/worktrees"
  fi

  # 2/3. Advisory only — a true statement about a tree that is nonetheless the right one.
  is_linked_worktree || warn "tree is not a linked worktree (D0.0 isolation): $root"

  base=$(resolve_base_ref)
  if [[ -z "$base" ]]; then
    warn "integration branch unresolved — skipping ancestry check"
  elif git rev-parse --verify --quiet "$base" > /dev/null 2>&1; then
    git merge-base --is-ancestor "$base" HEAD 2> /dev/null \
      || warn "HEAD does not descend from $base — the branch may be stale; rebase before editing"
  else
    warn "integration branch $base is not resolvable in this tree — skipping ancestry check"
  fi

  return 0
}

ASSIGNED_ARG=""
STATE_PATH=""
STATE_GIVEN=""
QUIET=""
CMD="check"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --assigned)
      shift
      ASSIGNED_ARG="${1:-}"
      shift
      ;;
    --state)
      shift
      STATE_PATH="${1:-}"
      STATE_GIVEN="1"
      shift
      ;;
    --quiet)
      QUIET="1"
      shift
      ;;
    --self-test)
      CMD="self-test"
      shift
      ;;
    -h | --help) usage ;;
    *)
      printf >&2 'unknown argument: %s\n' "$1"
      usage
      ;;
  esac
done

# No --state given: resolve it through the shared ladder rather than a cwd-relative
# guess, which named the wrong tree's ledger whenever DV's cwd was not the repo root.
# Fail CLOSED (exit 2) only on a broken install (lib unreachable / resolver unreachable,
# rc 2) — that is a plugin defect, not an unresolved ladder. An unresolved ladder (rc 1)
# leaves STATE_PATH empty and falls into cmd_check's existing "-f" miss, which already
# degrades to WARN; inventing a second exit code for the same condition would just be two
# spellings of one outcome. Self-test never reaches here: it always passes --state.
if [[ "$CMD" == "check" && -z "$STATE_GIVEN" ]]; then
  STATE_LIB_PATH="$(dirname "${BASH_SOURCE[0]}")/../../shared/lib/state-read-lib.sh"
  if [ -r "$STATE_LIB_PATH" ]; then
    # shellcheck source=../../shared/lib/state-read-lib.sh
    # shellcheck disable=SC1090
    . "$STATE_LIB_PATH" || {
      printf >&2 'dv-tree-preflight: failed to source state-read-lib.sh at %s\n' "$STATE_LIB_PATH"
      exit 2
    }
  else
    printf >&2 'dv-tree-preflight: state-read-lib.sh unreachable at %s — plugin install broken\n' "$STATE_LIB_PATH"
    exit 2
  fi
  CTX_DIR="" CTX_RC=0
  CTX_DIR=$(corpflow_context_dir) || CTX_RC=$?
  if [[ "$CTX_RC" -eq 2 ]]; then
    printf >&2 'dv-tree-preflight: context-dir resolver unreachable — plugin install broken\n'
    exit 2
  fi
  [[ -n "$CTX_DIR" ]] && STATE_PATH="$CTX_DIR/state.json"
fi

# Dispatch table rather than a straight-line main: the blocking check is the same predicate
# a PreToolUse hook would need, so wiring one later is a new arm, not a rewrite.
case "$CMD" in
  check) cmd_check ;;
  self-test)
    # Sourced HERE, not at the top: the harness is test code the production path
    # never runs. `[ -r ]` first, not a bare `.`: sourcing a missing file with the
    # `.` builtin is a special-builtin error that exits the shell immediately,
    # bypassing an `if ! . …` guard entirely.
    SELFTEST_LIB_PATH="$(dirname "${BASH_SOURCE[0]}")/dv-tree-preflight-selftest.sh"
    if [ -r "$SELFTEST_LIB_PATH" ]; then
      # shellcheck source=dv-tree-preflight-selftest.sh
      # shellcheck disable=SC1090
      . "$SELFTEST_LIB_PATH"
    else
      printf >&2 'dv-tree-preflight: self-test harness unreachable at %s — plugin install broken\n' \
        "$SELFTEST_LIB_PATH"
      exit 2
    fi
    run_self_test
    ;;
  *)
    printf >&2 'unknown command: %s\n' "$CMD"
    usage
    ;;
esac
