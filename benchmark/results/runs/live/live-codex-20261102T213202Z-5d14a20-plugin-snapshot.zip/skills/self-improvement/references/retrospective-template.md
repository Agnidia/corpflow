# Retrospective Template — learnings.md

Canonical shape of `.context/learnings.md`. The self-improvement skill fills in each block; out-of-context diffs never reach this file.

## Header Block

```markdown
# Self-Improvement Learnings — <worktask_id>

**Generated:** <UTC timestamp>
**Diff range:** <agent_sha>..HEAD
**In-context targets:** <count>
**Proposals:** <count> active, <count> deferred
```

## Section 1 — What Worked (mandatory)

Agents whose output survived user review unchanged — positive signal (4Ls: "Liked"). One bullet per agent, naming the artifact it produced.

```markdown
## What Worked

- `agents/product-manager.md` — `<plan_file>` (e.g. `planning-0.md`) accepted without edits
- `agents/qa-engineer.md` — testing-N.md accepted without edits
```

If no agents fit → write `- (none — every in-scope artifact was edited)`.

## Section 2 — What the User Changed (mandatory if any diff)

One bullet per diff hunk: path, line range, category, one-line summary. Detail belongs in Proposals.

```markdown
## What the User Changed

- `.context/development-N.md` L42–55 — `tone` — reworded approach summary
- `src/Models/User.swift` L18 — `domain-knowledge` — added Sendable conformance
```

## Section 3 — Proposed Updates (mandatory if any in-scope change)

Numbered checklist. **Each item is independently approvable** — the orchestrator passes only the ticked boxes on, each to the agent its `Enforcement:` form names (`SKILL.md § Handoff to the applying agent`).

**Ordering:** `confidence desc`, then `category`, then target path asc — high-confidence items first, so the user approves the strongest signals quickly.

### Proposed Updates Example

~~~markdown
## Proposed Updates

- [ ] **#1 — agents/developer.md — `completeness` — confidence: high**
  - **Observed:** user added Sendable conformance to Swift 6 actor types in 2 files (`src/Models/User.swift` L18, `src/Models/Order.swift` L22)
  - **Enforcement:** `judgement` — conformance depends on how the type crosses actors, so no fixed pattern catches it; a prose constraint for the implementer
  - **Proposed edit:** append to Constraints (DO NOT):
    ```markdown
    - DO NOT define types used across actor boundaries without `Sendable` conformance
    ```
  - **Target location:** `agents/developer.md` line 18 (end of Constraints block)
  - **Version bump:** `version:` minor (new constraint)
  - **Rationale:** Swift 6 strict concurrency requires Sendable; repeated correction signals missing domain knowledge.
~~~

### Proposed Updates shape

Every proposal repeats the shape of the example above — checkbox header, Observed, Enforcement, Proposed edit, Target location, Version bump, Rationale — only the content varies (a `structure`/medium item would carry a diff block as its edit and a patch bump). `Observed` cites the hunk's path and line range. `Enforcement:` is `mechanical` or `judgement` with one line of reason (`references/change-categories.md § Enforcement Form`); a `mechanical` item proposes a check, or the wiring of an unwired one, as its edit.

## Section 4 — Deferred (Low Confidence)

Observational only. The user can skim but is not asked to act.

```markdown
## Deferred (Low Confidence)

- `.context/planning-0.md` L8 — single-word wording tweak (`approach` → `strategy`). Confidence: low. Park until N≥2 similar tweaks accumulate across worktasks.
```

## Section 5 — Out-of-Context Discards

Count only; the full list lives in `.context/logs/self-improve-<ts>.log`, keeping `learnings.md` user-focused.

```markdown
## Out-of-Context Discards

12 diffs discarded (not mapped to an in-context target). See `.context/logs/self-improve-20260420-172301.log` § Discards.
```

## Footer — Approval Flow

Always include this block; it is how the user learns what happens next.

```markdown
---

## How to approve

1. Check the boxes next to any Proposed Updates you accept.
2. Leave unchecked any you reject.
3. Commit nothing — the orchestrator reads this file, hands checked `judgement` items to `prompt-engineer` and checked `mechanical` items to `workflow-engineer`, and each applied proposal becomes its own commit with a version bump.
4. Rollback-safe: revert any applied proposal via `git revert <sha>`.
```
