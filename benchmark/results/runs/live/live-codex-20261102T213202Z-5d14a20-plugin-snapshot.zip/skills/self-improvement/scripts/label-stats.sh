#!/usr/bin/env bash
# @file        label-stats.sh
# @description Aggregates evals/failure-labels.jsonl into per-target and
#              per-category counts — the input error analysis reads to find which
#              agents/skills the user corrects most, and in what way.
#
# @usage       label-stats.sh [--dataset=<file>] [--plugin-data=<dir>] [--format=table|json] [--min-count=<n>] [--self-test]
#
# @arg --dataset=<file>  JSONL label dataset (default: resolved by plugin-data-lib.sh)
# @arg --plugin-data=<dir> Plugin data root (see plugin-data-lib.sh)
# @arg --format=<fmt>    table (default) or json
# @arg --min-count=<n>   Recurrence threshold: flag targets/categories with at
#                        least n labels (default 3; 0 disables the section)
# @arg --self-test       Run internal test suite; exit 0/non-zero
#
# @exitcode 0  success (including an empty or absent dataset)
# @exitcode 1  usage/environment error
# @exitcode 2  self-test failure
# @exitcode 3  plugin-data-lib.sh unreachable — plugin install broken
#
# @requires    bash >=3.2, jq
# @min_shell   bash 3.2 (macOS system bash compatible)

set -Eeuo pipefail
IFS=$'\n\t'

trap 'printf >&2 "error: %s:%d: exit %d\n" "${BASH_SOURCE[0]}" "$LINENO" "$?"' ERR

# `[ -r ]` first: `.` on a missing file exits a `set -e` shell before any guard runs.
LIB_PATH="$(dirname "${BASH_SOURCE[0]}")/plugin-data-lib.sh"
if [ -r "$LIB_PATH" ]; then
  # shellcheck source=skills/self-improvement/scripts/plugin-data-lib.sh
  # shellcheck disable=SC1090
  . "$LIB_PATH"
else
  printf >&2 'label-stats: plugin-data-lib.sh unreachable at %s — plugin install broken\n' \
    "$LIB_PATH"
  exit 3
fi

# Row count at which evals/README.md unblocks writing failure-taxonomy.md.
TAXONOMY_THRESHOLD=100

DATASET=""
PLUGIN_DATA=""
FORMAT="table"
MIN_COUNT=3
SELF_TEST=0

usage() {
  printf >&2 'usage: %s [--dataset=<file>] [--plugin-data=<dir>] [--format=table|json] [--min-count=<n>] [--self-test]\n' \
    "${0##*/}"
  exit 1
}

for arg in "$@"; do
  case "$arg" in
    --dataset=*)     DATASET="${arg#*=}" ;;
    --plugin-data=*) PLUGIN_DATA="${arg#*=}" ;;
    --format=*)      FORMAT="${arg#*=}" ;;
    --min-count=*)   MIN_COUNT="${arg#*=}" ;;
    --self-test)     SELF_TEST=1 ;;
    *) usage ;;
  esac
done

case "$MIN_COUNT" in
  ''|*[!0-9]*) printf >&2 'label-stats: --min-count must be a non-negative integer\n'; exit 1 ;;
esac

if ! command -v jq >/dev/null 2>&1; then
  printf >&2 'label-stats: jq not found\n'
  exit 1
fi

stats_json() {
  # `recurring` reports; it never acts. Acting on a repeat stays gated on the
  # human approval of a Step 5 proposal.
  jq -s --argjson min "$2" --argjson taxonomy "$TAXONOMY_THRESHOLD" '
    (group_by(.target) | map({key: .[0].target, value: length}) | from_entries) as $targets |
    (group_by(.category) | map({key: .[0].category, value: length}) | from_entries) as $categories |
    {
      total: length,
      worktasks: ([.[].worktask_id] | unique | length),
      by_target: $targets,
      by_category: $categories,
      by_confidence: (group_by(.confidence) | map({key: .[0].confidence, value: length}) | from_entries),
      recurrence_threshold: $min,
      recurring: {
        targets: (if $min > 0 then ($targets | with_entries(select(.value >= $min))) else {} end),
        categories: (if $min > 0 then ($categories | with_entries(select(.value >= $min))) else {} end)
      },
      taxonomy: {rows: length, threshold: $taxonomy, ready: (length >= $taxonomy)}
    }' "$1"
}

render() {
  local dataset="$1" format="$2" min="$3"
  if [ ! -s "$dataset" ]; then
    printf 'no labels yet (%s)\n' "$dataset"
    return 0
  fi
  if [ "$format" = "json" ]; then
    stats_json "$dataset" "$min"
    return 0
  fi
  stats_json "$dataset" "$min" | jq -r '
    "labels: \(.total)  worktasks: \(.worktasks)",
    "taxonomy trigger: \(.taxonomy.rows)/\(.taxonomy.threshold) rows — \(if .taxonomy.ready then "READY" else "not yet" end)",
    "",
    "by target:",
    (.by_target | to_entries | sort_by(-.value) | .[] | "  \(.value)\t\(.key)"),
    "",
    "by category:",
    (.by_category | to_entries | sort_by(-.value) | .[] | "  \(.value)\t\(.key)"),
    (if .recurrence_threshold > 0 then
      "",
      "recurring (>=\(.recurrence_threshold)):",
      (( (.recurring.targets | to_entries | map(. + {kind: "target"}))
       + (.recurring.categories | to_entries | map(. + {kind: "category"})) )
       | sort_by(-.value)
       | if length == 0 then ["  none"] else map("  \(.kind)\t\(.value)\t\(.key)") end
       | .[])
     else empty end)'
}

if [ "$SELF_TEST" -eq 1 ]; then
  # Sourced HERE, not at the top: the harness is test code the production path
  # never runs. `[ -r ]` first, not a bare `.`: sourcing a missing file with the
  # `.` builtin is a special-builtin error that exits the shell immediately,
  # bypassing an `if ! . …` guard entirely.
  SELFTEST_LIB_PATH="$(dirname "${BASH_SOURCE[0]}")/label-stats-selftest.sh"
  if [ -r "$SELFTEST_LIB_PATH" ]; then
    # shellcheck source=skills/self-improvement/scripts/label-stats-selftest.sh
    # shellcheck disable=SC1090
    . "$SELFTEST_LIB_PATH"
  else
    printf >&2 'label-stats: self-test harness unreachable at %s — plugin install broken\n' \
      "$SELFTEST_LIB_PATH"
    exit 2
  fi
  self_test || exit 2
  exit 0
fi

si_resolve_dataset "$DATASET" "$PLUGIN_DATA" "${BASE_PLUGIN_DATA:-}" "failure-labels.jsonl" || exit 1
DATASET="$SI_DATASET_PATH"
[ -f "$DATASET" ] || { printf 'no labels yet (%s)\n' "$DATASET"; exit 0; }
render "$DATASET" "$FORMAT" "$MIN_COUNT"
