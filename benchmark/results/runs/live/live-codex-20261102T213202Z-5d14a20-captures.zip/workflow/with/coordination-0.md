---
handoff:
  stage: TL
  verdict: ok
  summary: "One developer executes five ordered tracks; Swift 6 and Apple SDKs are the planned dependencies."
  next_stage_focus: "Implement engine, views, sound, persistence, then tests in one DV0 stream; verify package and both hosts."
  open_questions: []
  requests_test_evidence: "DV/QA: run headless swift build and swift test, verify CLI bytes and macOS/iOS builds; observe animations and audio."
  refs:
    plan: .context/planning-0.md#requirements
    arch: .context/architecture-0.md#decisions
    fan_out: coordination-0.md#fan-out
---

## fan-out

One DV0 owner handles these ordered tracks: shared interfaces and tightly coupled view models make a parallel split inefficient. The benchmark dispatcher owns DV0 assignment and downstream ledger rows; none exist yet.

1. **Engine:** `Board`, `GameEngine`, `AIOpponent`, AI worker and scripted CLI; establish SwiftPM package and executable.
2. **Views and transitions:** `AppRootView`, game, leaderboard and settings views, router and view models; implement animations and thin macOS/iOS hosts against injected service interfaces.
3. **Sound:** `SoundPlaying`, controller, platform implementations and bundled cues; connect the views through the established interface.
4. **Persistence:** Codable `Leaderboard` and `GameSettings`, injectable score/settings stores and completion-id protection; connect existing view models.
5. **Tests:** Swift Testing suites for Kit and CLI, including engine/AI, view models, persistence, sound fakes and exact CLI output.

## shared-snippets

Use the exact interfaces and names in architecture-0.md#integration-points. UI depends on `ScoreStoring`, `SettingsStoring`, `SoundPlaying` and `AIMoveChoosing`; inject implementations, URLs and randomness. CLI uses the engine without initializing GUI, stores or audio.

## sequence

AR → TL → DV0 tracks 1–5 → DR → QA → FN → ST. Each track follows the previous track; DR waits for DV0, and QA follows review. Temporary implementations or protocol definitions can support the earlier views track until sound and persistence land.

### Quality gates

- **Must-fix:** Swift 6 package builds and headless Swift Testing passes on a compatible Apple toolchain; verify exact CLI bytes and platform host builds.
- **Must-fix:** Meet architecture's game, navigation, persistence, concurrency and audio contracts; QA records screen, animation and audio evidence for both platforms.
- **Nice-to-have:** Improve documentation or polish without delaying the required behavior.

## risks

No product-design blockers identified. The design uses Swift 6, SwiftPM and Apple SDKs only, with no remote packages; headless `swift build` and `swift test` are the intended package checks. Buildability is not yet verified: the package does not exist, and available SDK versions have not been checked. The iOS app additionally requires its Xcode host and SDK; package checks alone do not establish iOS launch. The integration base remains an external dispatcher setup concern.

## elicitation-sweep

Nothing to elicit: the requested order and architecture specify the coordination decisions.
