## FN0 — blocked: upstream evidence and defects

Classification: `upstream_blocker`. QA verdict is no-go; Unicode case folding fails AC-7/AC-8, the `test-ios` target is missing, and native UI/launch evidence is unavailable. DV is blocked and DR failed. See `.context/testing-0.md#verdict` and `.context/developer-review-0.md#findings`. Required: corrected implementation and green QA evidence, including both platform walkthroughs and the full acceptance matrix.
