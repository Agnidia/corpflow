---
handoff:
  stage: PL
  verdict: ok
  summary: "Plan a SwiftUI Tic-Tac-Toe app for macOS and iOS with four screens, AI, persistence, sound, and scripted CLI."
  key_decisions:
    - { id: pd1, summary: "Share deterministic rules between the SwiftUI app, AI, tests, and scripted CLI.", anchor: "planning-0.md#scope" }
    - { id: pd2, summary: "Keep four screens and local persistence; preserve the CLI contract verbatim.", anchor: "planning-0.md#acceptance-criteria" }
  next_stage_focus: "Resolve SwiftPM and iOS app hosting; define engine, persistence, audio, and CLI boundaries."
  open_questions: []
  requests_test_evidence: "DV/QA: supply both platform builds, CLI byte comparisons, Swift Testing results, and screen evidence."
  refs:
    plan: .context/planning-0.md#requirements
title: "Define a runnable SwiftUI Tic-Tac-Toe benchmark app and exact scripted CLI"
metadata:
  test_mode: full
  always_required_tests: []
  ui_visual_check: true
  requires_screenshots: true
---

# SwiftUI Tic-Tac-Toe PRD

## requirements

### Problem and success metric

The benchmark needs a small playable app with observable behavior across UI, logic, persistence, and a strict CLI. The workspace contains only its task ledger at discovery; there is no existing app or test suite. Success metric: acceptance criteria verified against a delivered build, baseline **0/14**, target **14/14**. QA must record pass/fail and evidence for AC-1 through AC-14, then report the measured delta. No delivered-build results exist at PL.

### Required stories

All stories are P0 because the task requires them. RICE is a planning aid, not evidence of product demand: assume **100 evaluation users/quarter**, impact **2**, and confidence **100%** in the explicit scope. Effort uses 160 hours/person-month. These reach and effort values are hypothetical; the fixed benchmark contract takes precedence over ranking.

| ID | User story | Effort (person-months) | RICE = 100 × 2 × 1 / effort |
|---|---|---:|---:|
| REQ-1 | As an evaluator, I want a Swift 6 app on macOS 15+ and iOS 18+ so that I can launch both platforms offline. | 0.05 | 4,000 (P0) |
| REQ-2 | As a player, I want a main menu, game, leaderboard, and settings so that every action has a clear route home. | 0.05 | 4,000 (P0) |
| REQ-3 | As a player, I want legal alternating moves on a 3×3 board, animated placement, and a winning-line highlight so that I understand progress and results. | 0.05 | 4,000 (P0) |
| REQ-4 | As a solo player, I want easy random or hard minimax AI so that I can choose the challenge. | 0.05 | 4,000 (P0) |
| REQ-5 | As a returning player, I want persisted scores and sorted standings so that completed games remain visible after relaunch. | 0.025 | 8,000 (P0) |
| REQ-6 | As a player, I want saved player names, AI difficulty, and a sound toggle with move/win/draw/tap effects so that play follows my preferences. | 0.05 | 4,000 (P0) |
| REQ-7 | As an evaluator, I want the exact scripted CLI so that results can be compared byte-for-byte. | 0.05 | 4,000 (P0) |
| REQ-8 | As a maintainer, I want Swift Testing coverage for engine, models, and view-models so that rule and state regressions are detectable. | 0.025 | 8,000 (P0) |

REQ-1 also requires SwiftPM, Apple SDKs only, no third-party packages, and no network. REQ-8 test effort is included within feature delivery, not a separate testing phase.

## acceptance-criteria

Verification commands below are instructions for DV/QA; PL executes none. Proposed suite names are contracts for test organization, not claims that files already exist. GUI criteria also require a platform walkthrough; unit tests alone cannot prove rendering or sound.

- **AC-1 (REQ-1):** Given an offline checkout and the assumed Apple toolchain, when built through SwiftPM on macOS and the local iOS host on the simulator, then both launch a real SwiftUI main menu at the specified deployment floors. The executable product is named `tictactoe`; no arguments launches the macOS GUI, while `--moves` selects CLI before GUI or audio initialization.
  Verify: `swift build --product tictactoe`; `xcodebuild -project TicTacToe.xcodeproj -scheme TicTacToe-iOS -sdk iphonesimulator -configuration Debug CODE_SIGNING_ALLOWED=NO build`; QA launches each resulting app.
- **AC-2 (REQ-2):** Given the main menu, when each primary control is used, then the four-screen inventory and every route in the scope table work on both platforms. Back returns to the menu; abandoning an unfinished game records no result. Controls remain usable at a 375×667-point phone viewport and a 640×480-point Mac window.
  Verify: `swift test --filter NavigationViewModelTests`; QA traverses each route on both platforms and checks control bounds.
- **AC-3 (REQ-3):** Given a fresh game, when legal cells are selected, then X starts, X/O alternate, and occupied/out-of-range moves never mutate the state. All eight winning triples and a full-board draw are recognized; wins take precedence over draws. After a terminal result, further moves are ignored. Restart clears the board and restores X without scoring an abandoned game.
  Verify: `swift test --filter GameEngineTests`.
- **AC-4 (REQ-3):** Given a game, when a legal move is accepted, then its mark visibly scales/fades into its cell; an occupied tap causes no placement animation. A win visibly highlights the winning three-cell line and announces the winner; a draw announces a draw without a winning line. Input remains locked after completion and during the AI turn. Reduced Motion uses immediate placement/highlight. Replay resets highlights and status.
  Verify: `swift test --filter GameViewModelTests`; QA observes placement, all line directions, draw, replay, and Reduced Motion on both platforms.
- **AC-5 (REQ-4):** Given solo mode with human X and AI O, when a human move leaves an ongoing game, then easy selects one legal empty cell through an injectable random source; hard uses minimax and cannot lose against any legal human continuation. Neither difficulty moves on a terminal/full board. Restart or navigation cancels/discards any stale AI result.
  Verify: `swift test --filter AIOpponentTests`; exhaustive human-continuation checks for hard plus seeded easy selection and stale-result view-model tests.
- **AC-6 (REQ-5):** Given local persisted standings, when a UI match finishes, then each participant receives exactly one outcome update, including the reserved AI participant in solo mode. Re-rendering or revisiting the result never duplicates the update. A restart before completion or CLI session changes no standings. Relaunch restores the same counts; absent/corrupt storage recovers to usable empty standings without a crash.
  Verify: `swift test --filter ScoreStoreTests`; QA completes games and relaunches the app on each platform.
- **AC-7 (REQ-5):** Given participant win/draw/loss counts, when the leaderboard opens, then it shows names, wins, draws, losses, and points (win 3, draw 1, loss 0). Sort by points descending, then wins descending, then case-folded name ascending, with original name as the final stable tie-break. No games shows a clear empty state and a route home.
  Verify: `swift test --filter LeaderboardViewModelTests`; fixture: Alice (1W/0D/1L, 3 points), Bob (1W/0D/0L, 3), Cara (0W/2D/0L, 2) sorts Alice, Bob, Cara.
- **AC-8 (REQ-6):** Given settings, when sound, difficulty, or either player name changes, then the change persists across relaunch. Defaults are sound on, easy, `Player 1`, `Player 2`. Names trim surrounding whitespace, allow 1–20 characters, and must be distinct case-insensitively and different from reserved `Computer`; invalid edits show inline feedback and preserve the last valid values. Name/difficulty edits apply to the next game; sound changes apply immediately. Historical scores retain their saved names; a new name starts a new identity.
  Verify: `swift test --filter SettingsViewModelTests`; `swift test --filter SettingsStoreTests`; QA changes each control and relaunches.
- **AC-9 (REQ-6):** Given sound enabled, when a valid move, win, draw, or menu/settings/replay action occurs, then its distinct move/win/draw/tap cue plays. Terminal moves produce a move cue and one outcome cue; cell selections do not also emit tap cues. Invalid moves produce no cue. With sound disabled all cues stop; an unavailable audio device never blocks gameplay. CLI emits no audio.
  Verify: `swift test --filter AudioEventTests`; QA listens to all four effects on both platforms and verifies silence with sound off.
- **AC-10 (REQ-7):** Given scripted mode, when a valid sequence is supplied, then stdout, exit status, early stopping, and board spaces conform to the contract below. Output uses LF line endings and a final LF, with no banners, logs, or ANSI escapes.
  Verify: `swift test --filter ScriptedCLIContractTests`; subprocess comparisons against the built `tictactoe` executable using byte buffers.
- **AC-11 (REQ-7):** Given any `--moves` argument, when parsed, then spaces/tabs around tokens are accepted, empty tokens contribute no move, newlines remain unparseable, and every token is parsed before any move is applied. Malformed syntax returns 2, diagnostic stderr, and zero stdout bytes even if an earlier move is occupied, out of range, or already wins.
  Verify: `swift test --filter ScriptedCLIParsingTests`; include every parsing row in the CLI matrix below.
- **AC-12 (REQ-7):** Given a completely parsed list, when a move before game completion targets an occupied cell or lies outside 0..8, then exit is 1, stderr is nonempty, and stdout is empty even if earlier moves succeeded. Once a valid prefix wins/draws, remaining syntactically valid moves are not applied or legality-checked.
  Verify: `swift test --filter ScriptedCLIContractTests`; include invalid, terminal, and early-stop matrix rows below.
- **AC-13 (REQ-8):** Given the package test targets, when Swift Testing runs, then engine, persistence/settings/result models, AI, navigation, game, settings, and leaderboard view-model suites pass, using isolated stores, seeded randomness, and fake audio. No tests read or overwrite real player defaults.
  Verify: `swift test`; QA records suite counts, failures, and evidence for every criterion rather than declaring coverage from filenames.
- **AC-14 (REQ-1, REQ-8):** Given the delivered repository, when package dependencies, sources, resources, and README are reviewed, then all dependencies are Apple SDKs or local targets, sound resources ship locally, deployment targets are correct, and the README explains macOS launch, iOS host launch, CLI quoting, and tests. Neither app nor tests require network access.
  Verify: `swift package dump-package`; `git grep -n -E 'https?://|URLSession|import (Alamofire|ArgumentParser)|\.package\(url:' -- .` (review all matches); inspect README and local host settings.

### Scripted CLI contract — verbatim task text

```text
SCRIPTED CLI CONTRACT — implement exactly; conformance is graded:
`tictactoe --moves 0,4,1` plays those cell indices in order as alternating
turns starting with X, stopping early once the game is won or drawn. It then
prints the board followed by a `result:` line, e.g. for no moves at all:

 0 | 1 | 2
---+---+---
 3 | 4 | 5
---+---+---
 6 | 7 | 8
result: in_progress

- a played cell shows `X` or `O`; an unplayed cell shows its own index digit
- every board row has one leading and one trailing space, as shown
- the last line is `result: ` plus one of `in_progress`, `X_wins`, `O_wins`,
  or `draw`
- exit 0 when the sequence played; 1 when a move is invalid (occupied cell or
  outside 0..8); 2 when --moves is not a comma-separated integer list
- diagnostics for exit 1 and 2 go to stderr; their wording is not graded, and
  stdout stays empty on both — the board prints only on exit 0
- whitespace around move tokens is accepted (`0, 4, 1` is valid); whitespace
  here means spaces and tabs only, so a newline inside a token leaves it
  unparseable and exits 2
- the whole list is parsed before any move is played, so a malformed token
  exits 2 even when an earlier token is an invalid move
- an empty token contributes no move rather than failing the parse, so `0,,4`
  and a trailing comma are both valid
```

### Canonical expected stdout bytes

These blocks explicitly include the required trailing space on each board row. In escaped notation the first row below is `" 0 | 1 | 2 \n"`; separator lines are `"---+---+---\n"`. A successful CLI writes exactly six lines and nothing to stderr. An explicitly empty value (`tictactoe --moves ""`) is the no-moves scripted case; launching without flags is the GUI case. Missing `--moves` value returns 2.

`tictactoe --moves ""`:

```text
 0 | 1 | 2 
---+---+---
 3 | 4 | 5 
---+---+---
 6 | 7 | 8 
result: in_progress
```

`tictactoe --moves 0,4,1`:

```text
 X | X | 2 
---+---+---
 3 | O | 5 
---+---+---
 6 | 7 | 8 
result: in_progress
```

| Argument value (shell quoting removed) | Exit | Result / required behavior |
|---|---:|---|
| empty string; `,,`; spaces/tabs only | 0 | Unchanged board, `in_progress` |
| `0, 4, 1`; `0,\t4,\t1` with literal tabs | 0 | Same bytes as `0,4,1` |
| `0,,4`; `0,4,` | 0 | X at 0, O at 4, `in_progress` |
| `0,3,1,4,2` | 0 | `X_wins`; X across 0/1/2 |
| `0,3,1,4,8,5` | 0 | `O_wins`; O across 3/4/5 |
| `0,1,2,4,3,5,7,6,8` | 0 | `draw`, nine occupied cells |
| `0,3,1,4,2,9,0` | 0 | Same bytes as the X win; ignore later legal-syntax tokens |
| `0,0`; `9`; `-1`; `0,4,0` | 1 | Empty stdout; nonempty stderr |
| `a`; `1.0`; `0,4x`; `0,1 2` | 2 | Empty stdout; nonempty stderr |
| `0,\n4,1` with a literal newline | 2 | Do not trim the newline into validity |
| `0,0,nope`; `9,nope`; `0,3,1,4,2,nope` | 2 | Full-list syntax error takes precedence |

### Residual review

For the final implementation, review repository-wide matches per theme: `git grep -n -E 'TODO|FIXME|fatalError|preconditionFailure' -- Sources Tests` (no unimplemented paths); `git grep -n -E 'print\(|standardOutput|standardError|--moves' -- Sources Tests` (no CLI stdout pollution); `git grep -n -E 'UserDefaults|FileManager|AVFoundation|AudioToolbox' -- Sources Tests` (isolated storage, sound gating, local assets). Swift symbol anchors: `git grep -n -w -e GameEngine -e GameViewModel -e SettingsViewModel -e LeaderboardViewModel -- Sources Tests`. AR may select equivalent names and must update these anchors before implementation. These checks supplement behavioral verification.

## scope

### Screen inventory and UX flows

| Screen | Content and states | Navigation / action |
|---|---|---|
| Main menu | App title, local-two-player / vs-computer mode picker, Start Game, Leaderboard, Settings | Start creates a fresh game with saved names/difficulty; other buttons open their named screen |
| Game | Names and X/O assignments, turn/AI-thinking status, 3×3 board, animated pieces, result text, winning line, Restart/Play Again, Main Menu | Restart/Play Again clears the match; Main Menu abandons an unfinished match; after completion an inline Leaderboard action opens standings |
| Leaderboard | Sorted participant rows with W/D/L and points, or empty state | Back/Main Menu always returns to menu, including when opened after a game |
| Settings | Sound toggle, easy/hard picker, two player-name fields with inline validation | Valid changes save immediately; Back returns to menu; difficulty only affects solo mode |

The result is a state inside Game, not a fifth screen. Empty, thinking, finished, and invalid-name feedback are inline. Use native SwiftUI navigation and controls, scalable text, keyboard activation on Mac, and accessible cell labels identifying index/row/column and occupancy. Highlight and text both identify a win. No custom design system or asset acquisition is needed.

### Game, data, and platform boundaries

- Local play alternates two humans; solo mode is human X versus reserved `Computer` O. X starts every replay. Match settings are captured at game start. Board cells use row-major indices 0–8.
- One pure engine owns legal moves, turn, result, and winning cells. Both front ends and AI consume these rules. Minimax is local and bounded by the nine-cell board; deterministic tie-breaking is allowed. AI work must leave UI responsive and avoid Swift 6 isolation violations.
- Standings track exact validated display names and W/D/L counts; points are derived. Settings and scores persist locally using Foundation storage, with test-isolated stores. No match resume is required. Only completed GUI matches update standings, once per match.
- SwiftPM owns shared logic, SwiftUI presentation, executable, resources, and Swift Testing targets. Provide a minimal checked-in Apple app host/project for iOS that consumes the local package. The Mac executable must actually open its SwiftUI window. AR records the entry-point/resource strategy before DV; CLI must run without a GUI session or audio setup.
- Proposed targets: `TicTacToeCore`, `TicTacToeUI`, `tictactoe`, and corresponding test targets. Store bundled move/win/draw/tap audio locally; Apple audio APIs only. CLI and core tests must not depend on a visible SwiftUI window.

### Delivery milestones

1. Establish package/platform hosts and pure engine with engine/model tests; prove both platform builds.
2. Add the four screens, view-models, AI, local persistence, and sounds with their feature tests.
3. Add scripted CLI integration and exact-byte fixtures; complete QA walkthroughs and criterion verdicts.

One development stream owns the app. Estimated feature delivery including tests: **56 hours** (0.35 person-month); QA validation: **6 hours**. These are planning assumptions, not a delivery commitment.

## out-of-scope

- Accounts, identity verification, cloud sync, network multiplayer, telemetry, advertisements, payments, and third-party dependencies.
- App Store distribution, signing setup, CI deployment, release automation, achievements, match history, undo, saved unfinished games, configurable board size, themes, localization, and score reset/export.
- Additional screens, remote AI, AI difficulty levels beyond easy/hard, and implementation bodies in this PRD.

## risks

- Toolchain assumption: Xcode 16+ with Swift 6, SwiftPM, macOS 15 and iOS 18 SDK/simulator support. PL has not queried toolchain versions or built anything. DV must record actual versions and any compatibility gap.
- SwiftPM does not itself provide a deployable iOS application bundle. AR must specify the minimal local Xcode host and package resources; QA must prove iOS launch rather than treating a Mac build as multiplatform evidence.
- Swift 6 concurrency can expose UI/AI/audio isolation errors. Keep pure game rules independent of UI and inject side effects into view-models; invalidate AI work on restart/navigation.
- Fixed byte output is vulnerable to generic whitespace trimming, partial printing, and integer conversion order. Buffer output until successful playback; QA tests stdout/stderr separately, literal tabs/newlines, and error precedence.
- Audio-device availability and motion behavior need runtime evidence. Fake services prove event selection; physical/simulator observations prove presentation. Silent audio failure is nonfatal.
- Local aliases are gameplay labels, with no identity or sensitive data collection. AI only selects board moves. No tracking, protected population, or consequential automated decision is in scope; a separate ethics stage is not warranted.
- Integration base is unresolved: the local resolver returned no configured/default base. Do not guess `master` from the current branch. This is nonblocking for the PRD; the benchmark owns downstream dispatch and must supply any branch/isolation context it requires.
- User-research reach and time estimates are assumptions. No measured demand or runtime conformance is claimed; learning occurs when QA measures the 0/14 baseline against the delivered app.

## complexity

**28/50 — Moderate**, using five factors scored 0–10, not the separate 0–25 estimation rubric.

| Factor | Score | Basis |
|---|---:|---|
| New patterns | 7 | Greenfield engine, SwiftUI state/navigation, AI strategy, and CLI entry mode |
| Integration points | 6 | Shared engine, SwiftUI, two app hosts, persistence, audio, CLI, tests |
| Cross-cutting concerns | 7 | Concurrency, settings, score identity, deterministic rules, output isolation |
| Risk level | 5 | Byte contract and platform packaging require care; all data remains local |
| Documentation needs | 3 | README run/test instructions and architecture decisions; no public API manual |
| Total | **28** | **7 + 6 + 7 + 5 + 3** |

Default test mode is **full** at score 26+. Standard worktask tier; no emergency or secure surface is requested.

## stages

Recommended sequence: **PL0 → AR0 → DV0 → DR0 → QA0 → FN0 → ST0**. Only PL runs in this dispatch. Downstream rows cannot be seeded with a valid base while the integration base is unresolved; stage selection is recorded here for the benchmark's dispatcher. No downstream stage is started.

| Stage | Decision and reason |
|---|---|
| AR0 | Include: new module/data boundaries and SwiftPM/iOS hosting require recorded decisions |
| DV0 | Include: one developer implements the package, hosts, UI, and feature tests |
| DR0 | Include: independent review checks rules, isolation, and CLI precedence |
| QA0 | Include: full tests, CLI subprocess bytes, and both platform walkthroughs prove acceptance |
| FN0 | Recommend tier default for handoff bookkeeping; benchmark restrictions prohibit push, network, or external publication |
| ST0 | Recommend tier default to compare criterion verdicts and estimates after delivery |
| TL0 | Skip: one development stream needs no parallel coordination |
| SR0 | Skip: no credentials, authentication, protected assets, or security-sensitive service; CLI parsing stays in DR/QA scope |
| DC0 | Skip: a short README can be delivered and reviewed with the app |
| RE0 | Skip: no store release or published artifacts are requested |
| ET0 | Skip: local board-move selection and aliases do not create a consequential ethics surface |

## test-strategy

Framework: **Swift Testing** (`import Testing`, `@Test`, `#expect`) for unit and CLI subprocess tests. No existing tests need changes. GUI/sound checks use documented manual walkthroughs; no snapshot package or extra UI-test harness is required for this benchmark.

| Proposed suite/file under Tests | Minimum meaningful scenarios |
|---|---|
| TicTacToeCoreTests/GameEngineTests.swift | Initial state, alternating turns, each of 8 win triples for either mark, draw, occupied/out-of-range rejection, post-terminal lock |
| TicTacToeCoreTests/AIOpponentTests.swift | Seeded easy legality/variation, terminal no-move, immediate hard win/block, exhaustive hard never-loses continuations |
| TicTacToeCoreTests/ScoreStoreTests.swift | Win/draw/loss round trips, duplicate completion guard, corrupt/missing storage, CLI/abandon no-write |
| TicTacToeCoreTests/SettingsStoreTests.swift | Defaults, full round trip, invalid stored values fallback |
| TicTacToeUITests/GameViewModelTests.swift | Human/AI transition, terminal state/highlight, restart during pending AI, once-only score update |
| TicTacToeUITests/NavigationViewModelTests.swift | Each menu route/back, game abandonment, post-game leaderboard route |
| TicTacToeUITests/SettingsViewModelTests.swift | Valid names, blank/too-long/duplicate/reserved rejection, next-match difficulty, immediate mute |
| TicTacToeUITests/LeaderboardViewModelTests.swift | Points calculation, complete sort ties, empty state |
| TicTacToeUITests/AudioEventTests.swift | Four cue mappings, disabled suppression, invalid move suppression, terminal event counts |
| TicTacToeCLITests/ScriptedCLIContractTests.swift | Built executable output bytes/status/stderr for AC-10/12 matrix, no GUI/store/audio side effects |
| TicTacToeCLITests/ScriptedCLIParsingTests.swift | Spaces/tabs, literal newline rejection, empty tokens/trailing comma, malformed-before-play precedence |

The `TicTacToeUITests` name denotes Swift Testing of view-models, not XCUITest. Dependencies must allow these suites to run without opening windows or playing audio. Inject persistence, RNG, audio, and pending-AI control; do not assert internal implementation steps.

DV test effort included in the 56-hour feature estimate: 4h engine/AI, 2h model/storage, 3h view-models, 3h CLI integration. QA: 2h full suite/CLI verification, 3h Mac/iOS navigation/persistence/audio walkthroughs, 1h evidence and per-criterion verdicts.

`requires_screenshots: true` and `ui_visual_check: true`: four new SwiftUI screens alter rendered output (S1/S3 apply). DV/QA evidence must show the menu, active board, winning board, leaderboard, and settings on both platforms. Include empty standings and draw states in the walkthrough. Screenshots do not prove animation/audio; record those observations separately. Any unavailable platform evidence stays explicitly unverified.

## summary

**28/50, Moderate; recommended stages AR0, DV0, DR0, QA0, FN0, ST0.** Include AR for new platform/data boundaries; retain implementation/review/QA; retain FN/ST for completion and learning. Skip TL for a single stream, SR/ET for the local game scope, DC for a short README, and RE because distribution is excluded.

Minimal deliverable: four SwiftUI screens on macOS 15+/iOS 18+, two play modes, easy random/hard minimax, local scores/settings, four local sound cues, a byte-exact scripted CLI, and Swift Testing suites. Defaults, scoring, name identity, and the minimal iOS host are explicit reviewable assumptions. Acceptance starts at 0/14; QA reports the delivered count and delta. PL has not built or tested the app. Unresolved integration base affects downstream setup, not the product requirements.

## elicitation-sweep

`open_questions: []` — Nothing to elicit: the task fixes the benchmark scope, and the documented defaults keep it minimal. Runtime evidence and downstream branch context are execution facts for later stages.
