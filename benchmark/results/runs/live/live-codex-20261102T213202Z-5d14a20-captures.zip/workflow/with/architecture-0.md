---
handoff:
  stage: AR
  verdict: ok
  summary: "Define TicTacToeKit, thin platform hosts, observable MVVM routing, isolated persistence, and deterministic tests."
  key_decisions:
    - { id: ad1, summary: "Validated score 28/50; consult deferred because dispatch forbids nested agents; Apple design assessed locally.", anchor: "architecture-0.md#decisions" }
    - { id: ad2, summary: "TicTacToeKit owns MVVM/AppRouter and pure rules; tictactoe dispatches CLI before GUI composition.", anchor: "architecture-0.md#decisions" }
    - { id: ad3, summary: "Inject RNG, store URLs, sound, and AI worker; invalidate stale moves and persist completion IDs.", anchor: "architecture-0.md#decisions" }
  next_stage_focus: "DV: implement engine/CLI, stores, router/view-models, audio/views, then hosts; apply the test boundaries below."
  open_questions: []
  requests_test_evidence: "DV/QA: platform builds/launches, Swift Testing, exact CLI bytes, animation/audio and screen evidence."
  refs:
    plan: .context/planning-0.md#requirements
    decisions: architecture-0.md#decisions
---

# Tic-Tac-Toe architecture — run 0

## decisions

Scope: planning-0.md REQ-1–REQ-8 and AC-1–AC-14. Only this design and its required AR ledger patch belong to this stage.
The workspace has no package, source, project, or existing test suite. Apple is selected from the explicit SwiftUI product requirement.
Validated complexity remains **28/50, Moderate**: patterns 7, integrations 6, cross-cutting 7, risk 5, documentation 3.
The recommended PL→AR→DV→DR→QA→FN→ST sequence remains sufficient; no new surface warrants escalation. Benchmark dispatch owns downstream rows.
Consult gate opens for the first SwiftUI app pattern. Nested agents are forbidden in this dispatch; apply Apple architecture locally and record specialist review as deferred.

These accepted ADRs are embedded here; DV supplies all implementation bodies.

| ADR | Decision and rationale | Rejected alternative | Reversibility |
|---|---|---|---|
| ad1 | Retain PL's 28/50 and one development stream; all integrations are local and bounded. | Add coordination or security stages for already planned CLI input. | Reassess only for a newly discovered mandatory surface. |
| ad2 | One `TicTacToeKit` library with folder boundaries and a thin `tictactoe` executable; share rules and presentation between hosts. | PL's proposed Core/UI targets; the current task explicitly selects Kit. | Split targets later without changing public value types. |
| ad3 | `@MainActor @Observable` view-models and `AppRouter` own mutable UI state; views render and send intents. | Global singletons, view-owned game rules, or a reducer framework. | Replace presentation behind the engine/store interfaces. |
| ad4 | CLI dispatch precedes any SwiftUI App instance, stores, or audio construction; buffer stdout until success. | Run a scripted session through `GameViewModel`. | CLI adapter can move independently; byte contract stays fixed. |
| ad5 | Inject Codable JSON store URLs; atomically save scores plus completed-match IDs together. | UserDefaults globals or separate per-participant writes. | Schema-versioned migration can replace JSON. |
| ad6 | Pure minimax/random strategies run through an injected worker; match/revision checks reject stale results. | Minimax on the main actor or cancellation alone. | Worker scheduling can change without changing game rules. |
| ad7 | Inject gated `SoundPlaying`; use local WAV resources with platform implementations. | Device-dependent rules, remote assets, or sound calls in views. | Replace backend behind the protocol. |
| ad8 | SwiftPM owns Kit/resources/tests and Mac executable; a checked-in iOS Xcode app consumes the local library. | Treat a package executable as an installable iOS app. | Host packaging can change independently of Kit. |

## trade-offs

| Decision | Scalability and performance cost | Growth response |
|---|---|---|
| ad1 | One stream limits parallel throughput but avoids coordination for this small app. | Introduce streams only when ownership separates. |
| ad2 | CLI links Kit's SwiftUI-capable module, increasing link footprint; no GUI initialization is required. Folder boundaries rely on review. | Extract an engine target if headless distribution or independent reuse becomes a requirement. |
| ad3 | A single main-actor router serializes UI mutations; this is appropriate for one nine-cell match. | Separate scene state if independent simultaneous games become necessary. |
| ad4 | Parsing and output buffering use O(n) memory for the supplied list; full-list validation requires reading every token. | Preserve validation precedence if a future bounded-input policy is introduced. |
| ad5 | Small synchronous atomic JSON writes briefly occupy the main actor; scores and completion IDs grow O(matches/participants). | Add a storage actor/database when measured volume requires it; preserve the idempotent transaction. |
| ad6 | Minimax explores at most the nine-cell game tree; a worker hop adds negligible overhead and protects UI responsiveness. | Memoize only if profiling justifies it; retain deterministic ties. |
| ad7 | Four cached local audio players consume bounded memory; unavailable devices produce silent failure. | Evict/reload players if a larger asset catalog appears. |
| ad8 | A second host project adds maintenance and build verification; all feature code remains shared. | Keep only entry point and platform settings in the host. |

## patterns

### Package and file ownership

`Package.swift`: tools version 6.0, Swift language mode 6, `.macOS(.v15)` / `.iOS(.v18)`, no remote packages.
Products: `.library(name: "TicTacToeKit", targets: ["TicTacToeKit"])` and `.executable(name: "tictactoe", targets: ["tictactoe"])`.
Targets: `TicTacToeKit`, `tictactoe` → Kit, `TicTacToeKitTests` → Kit, and macOS subprocess target `TicTacToeCLITests` → Kit.
Folders below are architectural layers within **one Swift module**, not separate targets. Engine never imports SwiftUI, Observation, or audio frameworks.

| Proposed path | Ownership |
|---|---|
| `Sources/TicTacToeKit/Engine/{Board,Player,GameState,GameEngine,AIOpponent}.swift` | Sendable value rules, legal moves, outcomes, random/minimax strategy; no I/O. |
| `Sources/TicTacToeKit/Models/{Leaderboard,GameSettings,CompletedMatch,ScoreStore,SettingsStore}.swift` | Codable values, validation, ordering, injectable local persistence; Foundation only. |
| `Sources/TicTacToeKit/Services/{SoundPlaying,SoundController,PlatformSoundPlayer,AIWorker}.swift` | Audio boundary/platform backends; off-main AI execution adapter. |
| `Sources/TicTacToeKit/ViewModels/{AppDependencies,AppRouter,GameViewModel,SettingsViewModel,LeaderboardViewModel}.swift` | Main-actor composition, navigation, presentation state, effect coordination. |
| `Sources/TicTacToeKit/Views/{AppRootView,MainMenuView,GameView,LeaderboardView,SettingsView}.swift` | Cross-platform SwiftUI only; includes reusable board/cell views. |
| `Sources/TicTacToeKit/CLI/{ScriptedGame,BoardTextRenderer}.swift` | Pure argument-value parsing, engine playback, exact text formatting; no streams, stores, or audio. |
| `Sources/TicTacToeKit/Resources/Sounds/{move,win,draw,tap}.wav` | Four distinct local cues, processed by SwiftPM and found using `Bundle.module`. |
| `Sources/tictactoe/{Launcher,TicTacToeMacApp}.swift` | Custom `@main` dispatcher and Mac SwiftUI App type without another `@main`. |
| `Apps/iOS/TicTacToeApp.swift`, `TicTacToe.xcodeproj/` | Thin `@main` SwiftUI iOS host; local package product reference and shared `TicTacToe-iOS` scheme. |

### Dependency direction

`Views → ViewModels → Engine/Models + service protocols`; `AIWorker → AIOpponent → GameEngine`; platform audio implements `SoundPlaying`.
`CLI → Engine` only. `tictactoe → CLI` or `AppDependencies + AppRootView`; iOS host → the same composition/root view.
Expose host-facing root/composition and scripted adapter APIs publicly; keep remaining symbols internal and use `@testable import TicTacToeKit`.

## integration-points

| Caller → dependency | Interface / invariant |
|---|---|
| Hosts → `AppDependencies` | `@MainActor init(storageRoot: URL)` derives distinct settings/scores URLs and composes exactly one shared store pair, sound controller, router, and view-models. |
| Router → game | `startGame(mode: GameMode)`, `showLeaderboard()`, `showSettings()`, `goHome()`; leaving game invalidates AI before changing screen. |
| Game → engine | `GameEngine` owns `private(set) state: GameState`; `mutating func play(at index: Int) throws`; invalid/terminal moves leave state unchanged. |
| Game → AI | `AIMoveChoosing: Sendable`: `func move(for state: GameState, difficulty: Difficulty, randomIndex: @Sendable (Int) -> Int) async -> Int?`. Production `AIWorker` is an actor, separate from MainActor. |
| AI → pure strategy | `AIOpponent.chooseMove(in: GameState, difficulty: Difficulty, randomIndex: (Int) -> Int) -> Int?`; easy requests an index below the legal-cell count; hard ignores RNG. |
| Game → score store | `@MainActor ScoreStoring`: `record(_ match: CompletedMatch) throws`, `flush() throws`, read-only leaderboard; one transaction updates both participants and match ID. |
| Settings → store | `@MainActor SettingsStoring`: read-only `settings: GameSettings`, `save(_ settings: GameSettings) throws`; each store has `init(url: URL)`. |
| Game/router/settings → sound | `@MainActor SoundPlaying`: `play(_ cue: SoundCue)`, `stop()`; `SoundController` implements the same protocol, gates playback, and forwards to injected backend. |
| Views → state | `@Environment(AppRouter.self)` / `@Bindable` state as needed; SwiftUI lifecycle callbacks never record results or start duplicate AI work. |
| Launcher → scripted adapter | `ScriptedGame.run(_ moves: String) -> ScriptedResult`; result contains exit code, stdout, stderr. Launcher alone writes streams and exits. |

`GameViewModel` initializer injects mode/settings snapshot, `any ScoreStoring`, `any SoundPlaying`, `any AIMoveChoosing`, and `@Sendable` random-index closure.
The production RNG closure uses `Int.random(in: 0..<upperBound)`; seeded/sequence test closures protect mutable generator state with Swift 6 `Synchronization.Mutex`.
`SettingsViewModel` injects settings store and sound controller; `LeaderboardViewModel` injects score store. No component opens its own default global store.

## schemas

| Type / persisted document | Required shape and semantics |
|---|---|
| `Player`, `Board` | `.x` / `.o` marks, separate from participant names; nine row-major optional marks, read-only externally. |
| `GameState`, `GameResult` | Board, current mark, result `.inProgress`, `.win(player: Player, line: [Int])`, or `.draw`; legal play starts X, checks eight wins before draw, stops after completion. |
| `GameMode`, `Difficulty`, `SoundCue` | `.local` / `.solo`; `.easy` / `.hard`; `.move` / `.win` / `.draw` / `.tap`. |
| `AppScreen` | Hashable enum `.menu`, `.game`, `.leaderboard`, `.settings`; results stay inside `.game`. |
| `GameSettings` / `settings.json` | Version-1 envelope containing sound enabled, difficulty, player-one/player-two names. Defaults: true, easy, `Player 1`, `Player 2`. |
| `LeaderboardEntry`, `Leaderboard` / `scores.json` | Version-1 envelope with entries `{name, wins, draws, losses}` and completed match UUIDs. Counts are nonnegative; points derive as `3*wins + draws`. |
| `CompletedMatch` | Runtime UUID, terminal result, captured X/O display names; solo O is `Computer`. Never persist an unfinished match or CLI session. |
| `ScriptedResult` | Exit 0/1/2 and fully buffered stdout/stderr strings; success has six LF-terminated lines; errors have zero stdout bytes. |

Validate decoded envelopes and values; missing files return defaults/empty standings. Malformed/unsupported documents recover without a crash and expose a recoverable storage status.
Settings trim surrounding whitespace; names contain 1–20 Swift Characters, differ case-insensitively, and exclude `Computer` case-insensitively.
Invalid drafts retain the last valid settings and display inline feedback. Score identity is the exact validated saved name; edits never rename historical rows.
Sort by points descending, wins descending, name folded case-insensitively with a fixed POSIX locale ascending, then original name ascending.
Use `Data.write(to:options: .atomic)` within the injected directory; never split the two participant updates across files.
ScoreStore checks completed IDs before counting. On save failure it retains the dirty in-memory snapshot and exposes retry via `flush()`, without recounting.
SettingsStore validates and atomically writes before publishing valid persisted settings; expose a write failure rather than claiming a successful save.
Desktop development defaults to `<launch-workdir>/.tictactoe/`; tests inject `<workspace>/.context/test-data/<UUID>/`. No shared defaults or home-directory stores.
The iOS host injects a writable directory inside its app container, its runtime data workspace; it cannot access a desktop working directory.

### Scripted protocol

Only the Mac launcher examines process arguments. No arguments calls `TicTacToeMacApp.main()`; exactly `--moves <value>` selects scripting. Missing/unknown arguments return 2 on stderr.
Parse **every** comma-delimited token first; trim ASCII space/tab only, skip empty tokens, accept complete signed decimal Int tokens, reject embedded/newline characters.
A syntax failure returns 2 before gameplay, including malformed suffixes after illegal or winning prefixes. Then apply moves on a temporary engine.
An occupied/out-of-range move before termination returns 1 with empty stdout. After termination, ignore remaining parsed moves without legality checks.
Success renders the PRD's exact rows, separators, spaces, result spelling, and final LF; no `print` logging, banners, audio, or persistence.
Linking SwiftUI is permitted; constructing an App, NSApplication, audio backend, or persistent store on the CLI branch is forbidden.

## Swift App Architecture

> Apple architecture is assessed locally: this dispatch forbids nested consultants. Specialist consultation remains deferred; consider `/apple-developer:arch-select` separately.

`@MainActor @Observable final class AppRouter` drives `private(set) var screen: AppScreen = .menu` and owns the current game lifecycle.
`AppRootView` keeps the composition/router alive using SwiftUI `@State` ownership and switches on screen inside native navigation chrome.
All Back/Main Menu actions call `goHome()`, including leaderboard opened after a result; no independent navigation path can diverge from `AppScreen`.
Each leaderboard entry refreshes its view-model from the shared score store, including navigation immediately after a completed game.
`GameViewModel`, `SettingsViewModel`, and `LeaderboardViewModel` are `@MainActor @Observable`; dependencies/tasks are observation-ignored.
Starting/replaying captures names and difficulty, creates a fresh match UUID, restores X, and clears result/highlight. Sound reads the shared controller immediately.
Human input requires ongoing play, an empty valid cell, and no AI turn. An accepted move emits one move cue; transition to terminal emits one outcome cue.
Terminal handling occurs in the move intent, once per match, before any render/navigation; rendering a result has no effects.
Solo schedules an injected asynchronous worker with a Sendable state snapshot. Set thinking/disable input before awaiting it.
Restart/navigation cancels its task and increments a revision. On return, require matching revision/match UUID, unchanged board, ongoing state, and AI turn before applying a move.
The default worker confines synchronous minimax to its own actor. Hard maximizes O's outcome with deterministic lowest-index ties; terminal/full boards return nil.
Users select local/solo and difficulty; Restart/Main Menu override pending AI. This preserves the requested gameplay automation and adds no consequential automated decision.
Views use SwiftUI grids, semantic buttons, scalable text, placement scale/opacity, and a line overlay driven by winning indices.
Reduced Motion removes placement/highlight animation. Status text accompanies highlights; cell labels include index/row/column/occupancy.
Stable accessibility IDs: `menu.start`, `menu.leaderboard`, `menu.settings`, `game.cell.0`–`.8`, `game.restart`, `nav.home`, `settings.sound`.
Keep controls usable at 375×667 phone points and 640×480 Mac points; use scrolling/adaptive spacing rather than fixed oversized board geometry.
SoundController suppresses disabled cues and stops active playback when muted. Controls emit tap cues; cells emit only accepted move/outcome cues.
`PlatformSoundPlayer` uses `#if os(macOS)` AppKit `NSSound` and `#if os(iOS)` AVFoundation `AVAudioPlayer`; imports stay in Services.
Cache four `Bundle.module` WAV players; missing resource/device failures are nonfatal. Views import SwiftUI only.
The Mac App owns one window and shared composition. The iOS `WindowGroup` supplies the same root; set deployment target 18.0 and local package reference `.`.

## Test Architecture

### Testability Design Decisions

| Decision | Rationale | Test Impact |
|---|---|---|
| Pure Sendable engine and scripted adapter | Neither requires a UI lifecycle or side effects. | Parameterized rule/parse/byte tests run without windows. |
| Protocol injection and explicit URLs | Keep state and I/O under each test's control. | View-model tests use in-memory stores; storage tests exercise real Codable files in isolated workdir subdirectories. |
| Main-actor observable state; awaited AI seam | Swift 6 isolation is explicit; test scheduling stays deterministic. | Mark UI-state suites `@MainActor`; release controlled continuations rather than sleeping. |
| Swift Testing in both test targets | Apple toolchain provides `Testing`; no additional package dependency. | `@Suite`, `@Test`, `#expect`, `#expect(throws:)`; no XCTest for unit tests. |
| Host-independent Kit tests; Mac subprocess tests | Library imports must not launch App or audio. | CLI child process receives a workspace cwd/store root and captures byte buffers independently. |

### Test Doubles Strategy

| Component | Double Type (mock/in-memory/stub) | Purpose |
|---|---|---|
| RNG closure | stub | Fixed legal-index choices and mutex-protected seeded sequences prove easy legality and variation without unsafe Sendable captures. |
| `ScoreStoring`, `SettingsStoring` | in-memory | Observe values/write counts; inject write failures without using real player data. |
| Store URLs | stub | Unique `<workspace>/.context/test-data/<UUID>/`; missing, corrupt, invalid-version, and round-trip fixtures; clean up each directory. |
| `SoundPlaying` backend | mock | Record four cue events and stop calls; no device/session initialization. |
| `AIMoveChoosing` | stub | Suspend and release an old result after restart/navigation to prove revision rejection. |

### Test Boundaries

| Layer (domain/data/UI) | What to Test | What to Mock |
|---|---|---|
| domain — `Engine/GameEngineTests.swift` | AC-3: initial X, alternation, eight win triples for both marks, draw, rejected moves leave state unchanged, terminal lock. | Nothing. Construct fixtures from legal move lists. |
| domain — `Engine/AIOpponentTests.swift` | AC-5: easy legal/seeded selection, terminal nil, hard win/block; exhaust every human continuation with actual hard replies and assert no X win. | RNG only; never mock minimax or engine. |
| data — `Models/ScoreStoreTests.swift` | AC-6: both participants including Computer, W/D/L, record same UUID twice and after reload, atomic document round trip, missing/corrupt recovery, failed save/retry. | URL; use real Foundation I/O for persistence assertions. |
| data — `Models/SettingsStoreTests.swift` | AC-8: defaults, full round trip, corrupt/semantically invalid payloads, unsupported version, valid values retained after invalid edits. | URL and fixtures. |
| UI — `ViewModels/GameViewModelTests.swift` | AC-3–6: legal input, thinking lock, terminal highlight, once-only scores, replay/abandon behavior, stale worker completion, captured next-game settings. | Stores, sound, controlled AI, RNG. |
| UI — `ViewModels/NavigationViewModelTests.swift` | AC-2: all four router destinations, all home routes, fresh game on start, leaving game discards pending AI and unfinished score. | Stores/sound/AI through composition. |
| UI — `ViewModels/SettingsViewModelTests.swift` | AC-8: trimmed/boundary names, duplicate/reserved/blank/overlong rejection, valid-save behavior, immediate mute and next-game difficulty. | Settings store, sound backend. |
| UI — `ViewModels/LeaderboardViewModelTests.swift` | AC-7: empty rows, points, every sort tie, exact fixture Alice/Bob/Cara and preserved historical names. | Score store. |
| UI — `Services/AudioEventTests.swift` | AC-9: four cues, no invalid-move cue, terminal move+single outcome, no cell tap cue, immediate stop and suppression after mute. | Audio backend and game dependencies. |
| domain/adapter — `CLI/ScriptedCLIParsingTests.swift` | AC-11: every PRD parsing row, literal tabs/newlines, empty tokens, missing value, malformed precedence including terminal prefix. | Nothing. |
| integration — `TicTacToeCLITests/ScriptedCLIContractTests.swift` | AC-10/12: every PRD exit/output case against built executable; compare Data including row trailing spaces/final LF and independent stderr; assert no store files. | No app mocks; provide executable path from workspace build. |
| UI/platform — documented walkthrough | AC-1/2/4/6–9/14: both launches, all routes/states, persistence relaunch, animation/Reduced Motion, layout bounds, audible cues/mute, resources. | Nothing; screenshots plus observations, not unit-test claims. |

Kit test paths above live under `Tests/TicTacToeKitTests/`; CLI subprocess suites run on macOS only, via conditional manifest/source inclusion.
This replaces PL's proposed Core/UI test target names; retain suite/symbol names so AC filters and residual review anchors still work.
Framework compatibility is established from the Swift 6/Xcode 16 requirement, not an executed probe. Existing test structure: absent; no tests to update.
DV runs feature-scoped `swift test --filter <Suite>` and both PL build commands; QA owns full `swift test` and acceptance/evidence measurement.
QA obtains screenshots for all four screens plus active/winning board on both platforms; also walks empty standings, draw, and disabled/thinking controls.

## open-questions

No blocking architecture questions remain. Specialist consultation and runtime verification are deferred evidence, not user decisions.
The unresolved integration base remains the benchmark dispatcher's responsibility; this stage creates no branches or downstream tasks.

## risks

| Risk / assumption | Mitigation and evidence owner |
|---|---|
| Assume Swift tools/compiler 6.0+, Swift language mode 6, Xcode 16+, macOS 15+, iOS 18+ SDK/simulator and compatible local SwiftPM. No installed versions were queried. | DV records actual versions, builds both hosts, and reports incompatibilities before claiming launch evidence. |
| A package executable cannot install as an iOS app; hand-authored project references can drift. | Check in the minimal local host/shared scheme; DV builds the exact PL iOS command, QA launches the app and verifies resource lookup. |
| Strict concurrency errors or stale AI results can corrupt presentation. | Sendable snapshots, isolated worker, main-actor state, revision checks, deterministic continuation tests. |
| JSON corruption or failed writes can lose durable progress. | Validate version/payload, recover defaults, atomic replacement, retain dirty score snapshot, visible save status and retry; no false persistence claims. |
| Completion UUID history grows and atomic JSON is not a cross-process database. | Single GUI store owner, CLI never opens stores; measure before moving to a transactional database. |
| CLI strings can lose significant spaces or leak startup effects. | Independent pure parser/renderer, pre-GUI dispatch, full-list syntax precedence, subprocess byte fixtures and no-created-store assertions. |
| A sandbox cannot share desktop working paths. | All tests/development files use injected workspace URLs; iOS resolves only its runtime container. AR writes only inside the supplied workspace. |
| Audio and animations cannot be proven by mocks or source inspection. | Request DV/QA device/simulator observations and both-platform screenshots; record unavailable evidence as unverified. |
| Platform specialist consultation is unavailable under this dispatch restriction. | Explicit local Apple design above; DR reviews isolation, hosts, resources, and DI. Optional specialist review remains deferred. |

## elicitation-sweep

Nothing to elicit: explicit product requirements and reversible local architecture choices resolve this stage; `open_questions: []`.
