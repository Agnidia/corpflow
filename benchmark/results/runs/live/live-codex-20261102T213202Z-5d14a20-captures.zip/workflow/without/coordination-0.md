---
handoff:
  stage: TL
  verdict: ready
  worktask_id: live-codex-20261102T213202Z-5d14a20
  artifact: .context/coordination-0.md
  next_stage_focus: Implement the ordered tracks and verify package, CLI, and iOS host on Apple SDKs.
---

## fan-out

1. **Engine:** establish SwiftPM targets, Board/GameState and AIOpponent; implement the exact scripted CLI on the shared engine.
2. **Views and transitions:** RootView/router, GameView, Leaderboard and Settings; animations, accessibility, cancellable AI turns and session lifecycle.
3. **Sound:** inject SoundPlaying and implement Apple platform audio adapters, ordered effects and mute policy.
4. **Persistence:** Codable Leaderboard and GameSettings, shared versioned store, validation and exactly-once result recording.
5. **Tests:** Swift Testing suites for engine, AI, models, services, view-models and CLI; subprocess fixtures and Apple-host integration checks.

## shared-snippets

Agree target interfaces before UI work: pure engine and CLI in TicTacToeKit; main-actor router and services; injected sound, storage, randomness and AI scheduler. Use temporary in-memory adapters until later tracks integrate. Share screens with a minimal iOS host; keep CLI dispatch ahead of GUI initialization.

## sequence

Execute tracks in the listed order, integrating each against the preceding interfaces; test work may be prepared alongside implementation, with full verification last. Swift 6 and Apple SDKs supply the specified APIs without third-party dependencies; `swift build` and `swift test` are the headless package checks. A separate Xcode simulator build and manual GUI/audio checks remain necessary for the iOS host and visual behavior.

## risks

No product or architectural blocker is identified. This is a buildability assessment, not a successful build claim: the host reports Apple Swift 6.4.2 and a macOS SDK, but there is no implementation to build or test yet. Confirm iOS SDK/simulator availability and a permitted writable simulator workspace during integration; report an actual failure if either prevents verification. Keep build caches and persisted data within the permitted workspace.
