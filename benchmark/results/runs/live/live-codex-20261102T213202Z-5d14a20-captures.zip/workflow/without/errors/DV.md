# DV classified errors

## 2026-11-02-environment-apple-runtime-verification

- **Agent / worktask:** DV / live-codex-20261102T213202Z-5d14a20.
- **Classification:** environment / restricted Apple services and nested sandbox.
- **Verdict:** escalate for required runtime/manual verification; implementation and headless builds/tests completed.
- **Observed:** `sh Scripts/build-ios.sh` exits 74: `sandbox-exec: sandbox_apply: Operation not permitted` while resolving the local Swift package. After configuring workspace-local manifest/compiler caches, that sandbox restriction remains. `xcrun simctl --set "$PWD/.scratch/Devices" list runtimes` exits 1: CoreSimulatorService connection invalid/refused, POSIX 61; runtime/device services cannot be contacted. The macOS no-argument process stays alive, but GUI/XPC diagnostics occur and no visual inspection was possible.
- **Completed mitigation:** `sh Scripts/check.sh` passes all 24 Swift Testing tests; the real CLI process fixtures pass. `sh Scripts/build-ios-headless.sh` compiles/links/signs the actual simulator App bundle with Apple SDKs; signature and iOS Simulator 18.0 build-version validation pass. No downloads, permission escalation, or external user-directory writes were requested.
- **Evidence:** `.scratch/check.log`, `.scratch/ios-build.log`, `.scratch/ios-headless-build.log`, `.scratch/mac-gui-smoke.log`, and the command outcomes recorded in `.context/development-0.md`.
- **Impact / next owner:** A verification host with functioning GUI/CoreSimulator services must launch the app and check visual behavior, audio, accessibility, host storage, and relaunch persistence. These results were not fabricated and are not marked passed.
