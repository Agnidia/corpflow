
## 2026-11-02 — missing iOS test target

- Classification: implementation / verification blocker.
- `make test-ios` exited 2: no rule for target `test-ios`; no Makefile is present. The required simulator slice and clean no-runtime skip cannot be verified in this stage.
- Resolution: implementation should add the target and QA should rerun it on a suitable host. Verdict: escalate.
