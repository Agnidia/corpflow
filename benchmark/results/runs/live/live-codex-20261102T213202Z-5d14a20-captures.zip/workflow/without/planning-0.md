---
handoff:
  stage: PL
  verdict: ready
  worktask_id: live-codex-20261102T213202Z-5d14a20
  artifact: .context/planning-0.md
  next_stage_focus: Implement the SwiftPM app, shared engine, exact scripted CLI, local persistence, and Swift Testing coverage; verify on Apple SDK hosts.
---

# Tic-Tac-Toe benchmark PRD

## requirements

### Purpose and inputs

Build a small, real, runnable Tic-Tac-Toe app for macOS 15+ and iOS 18+. Success means four working SwiftUI screens, correct local and AI games, persisted standings and settings, and an executable whose scripted output meets the exact contract below. Keep implementation proportional to a benchmark workload.

The task prompt and stage contract are the planning inputs. Inspection found no files in `.context/`, including no additional metadata, upstream artifacts, or stage template. This artifact follows the supplied frontmatter and mandatory anchors. Planning does not claim any implementation or test execution.

### R1 — Platform and build

- Use Swift 6, SwiftPM, SwiftUI, Foundation, Apple audio APIs, and Swift Testing only. Declare macOS 15 and iOS 18 minimum deployment targets. Use no third-party packages, network calls, accounts, analytics, or downloaded assets.
- Keep game rules and data models in a platform-independent package target; share them between GUI, CLI, and tests. Isolate UI state to the main actor and satisfy Swift 6 concurrency checking.
- Provide a macOS SwiftPM executable product named `tictactoe`. Launching without CLI arguments opens the SwiftUI main menu. Dispatch scripted invocations before initializing GUI, audio, or persistent stores.
- Provide a minimal iOS application host using the same SwiftPM targets and four shared screens. A small Xcode host project is allowed: SwiftPM alone does not produce an installable iOS application bundle. Document exact macOS run/test and iOS simulator build/run commands in the implementation handoff or README.

### R2 — Rules and game state

- Use a 3×3 board indexed row-major from 0 through 8. X starts; valid moves alternate X and O. An occupied or out-of-range move fails without changing board, player, or result.
- Recognize all eight winning lines and a full-board draw. A terminal position accepts no further moves. The engine exposes the board, next player while active, result, and winning line when present.
- Support local two-player and human-versus-AI modes. Human is X and AI is O. Start every new game with an empty board. Do not persist an unfinished game.
- Animate each accepted piece placement. Highlight the winning three cells with a line through their centers; keep the final board and result visible until the user selects Play Again or Main Menu.

### R3 — AI

- Easy chooses uniformly among legal empty cells using injectable randomness.
- Hard uses full minimax search with terminal win/loss/draw evaluation. It must never lose from the normal initial position against any sequence of legal human moves. Break equal-value choices by lowest cell index for reproducibility.
- Schedule one AI response after a successful human move if the game remains active. Disable board input during the AI turn. Cancel or invalidate pending AI work when leaving the game or starting again; a stale response cannot affect another game.
- A small optional delay may make AI turns readable; tests must not depend on wall-clock sleeps. The board is small enough to use a synchronous minimax calculation within the scheduled turn.

### R4 — Standings and persistence

- Persist settings and leaderboard locally across launches using versioned Codable data in UserDefaults or a small local file. Inject storage into models/view-models for isolated tests. Missing or undecodable saved data falls back to safe defaults without crashing.
- Track three stable participant identities: player X, player O, and computer. Local games update X and O; AI games update X and computer. Renaming a player changes its displayed name without resetting its record. Both difficulty levels share the computer record.
- Each finished GUI game records one win and one loss, or one draw for each participant, exactly once. Abandoning a game records nothing. Merely revisiting a screen or rendering a terminal state must not record again. Scripted CLI games never modify scores or settings.
- Display participants with at least one completed game, showing name, wins, losses, draws, and points. Award 3 points per win, 1 per draw, and 0 per loss. Sort by points descending, wins descending, name ascending using a documented stable comparison, then stable participant ID. Show an empty-state message before any results exist.

### R5 — Settings and sound

- Settings contains a sound toggle, an Easy/Hard difficulty picker, and editable names for players X and O. Defaults: sound enabled, Easy, `Player X`, and `Player O`. Computer has the fixed label `Computer`.
- Trim surrounding whitespace from names; require nonempty, distinct names and reserve `Computer` to avoid ambiguous standings. Show validation inline. Persist valid edits; an invalid draft never overwrites the last valid value. Difficulty and names apply when the next game starts; sound changes apply immediately.
- Play four distinct short local effects: successful move, win, draw, and UI tap. Use bundled assets or generated tones through Apple audio APIs; require no microphone permission or network access. A terminal move produces its move effect followed by the relevant outcome effect. Invalid board taps produce no move sound. Disable all effects when sound is off; toggling off is silent.
- Keep sound failures nonfatal. Inject a sound interface so tests can inspect events without requiring audio hardware.

### R6 — Interaction quality

- Make the complete board and primary actions usable on iPhone portrait, iPad, and a resizable macOS window. A simple adaptive layout is enough; no device-specific feature set is needed.
- Use native buttons and labeled controls. Expose cell index/position and value to accessibility, announce the turn/result through readable status text, support keyboard activation of native controls on macOS, and respect Reduce Motion. A win must remain understandable from text and highlighted cells without relying on color, animation, or sound alone.

### R7 — Test surface

Use Swift Testing (`import Testing`, `@Test`, and parameterized cases as appropriate) for the engine, AI, Codable models, persistence, settings validation, standings order, and game view-model. Inject randomness, storage, sound, and AI scheduling where needed. Cover behavioral invariants, including terminal transitions, exactly-once recording, and cancellation, rather than UI rendering details.

## acceptance-criteria

### AC1 — Build and launch

On an Apple SDK host, the package builds with Swift 6, `swift test` passes, `swift run tictactoe` opens the macOS menu, and the iOS host builds for an iOS 18+ simulator and launches the same four screens. Report commands and actual results; do not substitute Linux-only checks for Apple UI verification. No package dependencies or runtime network access are present.

### AC2 — Complete screen flows

Both local and AI games can be started from Main Menu. Leaderboard and Settings open and return to Main Menu. Game offers Main Menu while active and Play Again after completion. Returning to Main Menu abandons an active game with no score update. Play Again preserves the selected mode and starts with current settings. No fifth screen or required modal is introduced.

### AC3 — Rules, animation, and outcomes

Engine tests cover each of the eight winning lines for both players, a draw, alternating turns, rejected occupied/out-of-range moves without mutation, and rejection after termination. Manual GUI checks confirm each accepted piece animates, the correct winning line appears, draw/winner text is visible, and terminal boards are disabled. Reduce Motion preserves clear state changes.

### AC4 — AI behavior and lifecycle

Seeded/injected randomness proves Easy selects only empty cells and handles terminal boards with no move. Tests check Hard's immediate win, forced block, and legal deterministic tie-breaks. Exhaustively explore legal human replies from an empty human-X/AI-O game to prove Hard never loses. View-model tests prove one AI response per turn, blocked human input on the AI turn, and no stale response after restart or navigation away.

### AC5 — Persistence and standings

Using an isolated store, complete one X win, one O win, and one draw; verify both participant records and point totals. Repeat terminal notifications and navigation and verify no duplicates. Verify ordering including ties, rename continuity, AI participant records, and empty standings. A fresh model instance restores saved records and settings. Missing/corrupt data produces defaults without a crash. CLI execution leaves the injected store untouched.

### AC6 — Settings and audio

Validate defaults, valid-name persistence, rejection of blank/duplicate/reserved names, sound toggle persistence, and both difficulty values. Test sound event dispatch for move/win/draw/tap and silence when disabled. Manually check all four sounds on an Apple host, graceful behavior when playback is unavailable, next-game difficulty/name changes, and accessible labels on all four screens.

### AC7 — Exact scripted CLI contract

The following block is carried verbatim from the task and is normative:

SCRIPTED CLI CONTRACT — implement exactly; conformance is graded:
`tictactoe --moves 0,4,1` plays those cell indices in order as alternating
turns starting with X, stopping early once the game is won or drawn. It then
prints the board followed by a `result:` line, e.g. for no moves at all:

 0 | 1 | 2
---+---+---
 3 | 4 | 5
---+---+---
 6 | 7 | 8
result: in_progress

- a played cell shows `X` or `O`; an unplayed cell shows its own index digit
- every board row has one leading and one trailing space, as shown
- the last line is `result: ` plus one of `in_progress`, `X_wins`, `O_wins`,
  or `draw`
- exit 0 when the sequence played; 1 when a move is invalid (occupied cell or
  outside 0..8); 2 when --moves is not a comma-separated integer list
- diagnostics for exit 1 and 2 go to stderr; their wording is not graded, and
  stdout stays empty on both — the board prints only on exit 0
- whitespace around move tokens is accepted (`0, 4, 1` is valid); whitespace
  here means spaces and tabs only, so a newline inside a token leaves it
  unparseable and exits 2
- the whole list is parsed before any move is played, so a malformed token
  exits 2 even when an earlier token is an invalid move
- an empty token contributes no move rather than failing the parse, so `0,,4`
  and a trailing comma are both valid

### AC8 — CLI conformance fixtures and boundary decisions

- Keep CLI turns literal and alternating regardless of GUI mode/difficulty; never insert AI turns. `--moves ""`, `--moves ",,"`, and space/tab-only empty tokens all contribute zero moves and print the empty board.
- Render the six output lines as UTF-8 with LF separators and a final LF. Preserve the required trailing space on each of the three board rows. Emit no headings, logs, ANSI styling, audio, or additional stdout text.
- Parse all tokens first, trimming only ASCII spaces/tabs. Require an entire nonempty token to be a base-10 integer; reject embedded whitespace, newlines, non-integers, and integer overflow as exit 2. Signed integers are parseable; negatives are invalid moves when reached. Missing `--moves` value and unsupported argument forms yield usage diagnostics on stderr and exit 2. No arguments selects GUI mode; an explicit empty value selects scripted mode.
- Apply parsed moves only until the first terminal position. Later integer tokens are ignored, including occupied/out-of-range indices; malformed later tokens still cause exit 2 because parsing precedes play. Buffer output until parsing and all reached moves succeed so failures emit zero stdout bytes.
- Capture stdout, stderr, and process exit status in conformance checks. Required fixtures: empty input; `0,4,1`; X win `0,3,1,4,2`; O win `0,3,1,4,8,5`; draw `0,1,2,4,3,5,7,6,8`; duplicate `0,0` (1); `9` and `-1` (1); `0,9,bad` (2); an actual newline inside a token (2); space/tab padding (0); `0,,4,` (0); terminal sequence followed by `99` (0); and terminal sequence followed by `bad` (2). Successful fixtures compare full output bytes, including spaces and the final LF; failure fixtures require empty stdout and a nonempty stderr diagnostic.

## scope

### Screen inventory

| Screen | Contents | Actions and destination |
| --- | --- | --- |
| Main Menu | App title; Local / vs Computer selector; Play; Leaderboard; Settings | Play creates a game and opens Game; other buttons open their named screen. Default mode is Local. |
| Game | Participant names/marks; current turn or result; 3×3 board; animated pieces; winning-line overlay; Main Menu; terminal Play Again | Cell plays a legal human move; AI replies when applicable; Main Menu abandons/finishes navigation; Play Again resets in place. |
| Leaderboard | Sorted persisted name/W/L/D/points rows or empty state; Main Menu | Main Menu returns to the menu; standings are read-only. |
| Settings | Sound toggle; Easy/Hard picker; two player-name fields; inline validation; Main Menu | Valid edits persist; Main Menu returns. Invalid name drafts are discarded on leaving, retaining valid saved names. |

### UX flows and state ownership

1. Launch → Main Menu → select mode → Play → Game. Initialize X's turn and snapshot current names/difficulty.
2. In Local, alternate human X/O taps; in vs Computer, human X → input locked → AI O → input unlocked if still active. Invalid or disabled taps do not change state.
3. Win/draw → animate final placement and show outcome/highlight → persist result once → Play Again or Main Menu. Input locks as soon as the engine becomes terminal, independent of animation completion.
4. Main Menu → Leaderboard → Main Menu, or Main Menu → Settings → edit → Main Menu. Starting another game picks up valid saved settings.
5. Active Game → Main Menu cancels pending AI, clears the session, and records nothing. Each new session gets an identity so delayed work and duplicate result callbacks cannot update it.

One simple navigation owner routes among the four screens. A game view-model owns a session, the pure engine owns rules, a standings/settings store owns persistence, and injected adapters handle sound and AI scheduling. Use a fixed-size board model and small Codable value types; avoid a general framework or service architecture.

## out-of-scope

- Online play, networking, accounts, cloud sync, matchmaking, chat, telemetry, monetization, and third-party code.
- More screens, onboarding, profiles management, score resets, match histories, themes, custom boards, undo, hints, difficulty levels beyond Easy/Hard, AI-vs-AI, and human playing O against AI.
- Restoring unfinished games, cross-device synchronization, persistence migration beyond safe version checks/defaults, and production asset pipelines.
- Store distribution, signing/provisioning for physical devices, localization, UI snapshot suites, performance benchmarking, and exhaustive visual automation. Basic accessibility and simulator validation remain in scope.

## risks

| Risk | Impact and mitigation |
| --- | --- |
| SwiftPM is insufficient for a deployable iOS GUI by itself | Include a minimal iOS host sharing package code; verify both Apple targets early. A macOS executable alone does not satisfy multiplatform acceptance. |
| CLI whitespace, parse precedence, or GUI initialization contaminates output | Separate argument parsing, full-list validation, simulation, and byte rendering. Dispatch before GUI startup; run process-level fixtures. Never trim newlines or print before success. |
| Delayed AI or repeated terminal callbacks corrupt state/scores | Session identity, cancellation, and a single guarded completion transition; deterministic view-model tests. |
| Persistence and renamed identities drift | Stable IDs, explicit ordering, versioned encoding, and isolated round-trip/rename tests. |
| Swift 6 isolation or Apple audio lifecycle differs across platforms | Keep models pure, UI/audio main-actor isolated, and perform Apple-host build and manual sound checks. |
| Required SDKs/simulator or audible output unavailable to the implementer | Report exact unverified criteria and actual commands/errors; do not claim completion from source inspection. If this prevents required delivery, the responsible stage records a classified error and uses blocked/escalate. |

## complexity

Score each factor from 0 (trivial) to 10 (high); total range is 0–50. Estimate: **28/50**, moderate for a small benchmark, driven by platform integration and exact conformance rather than game size.

| Factor | Score | Reason |
| --- | ---: | --- |
| Rules and AI | 5/10 | Small finite engine, full minimax, legal-move invariants, exhaustive no-loss verification. |
| UI and interaction | 6/10 | Four screens, two-device layout families, animations, winning geometry, accessibility, and navigation. |
| State and persistence | 5/10 | Two game modes, three participant identities, settings, deterministic standings, and exactly-once results. |
| Platform and integration | 6/10 | Swift 6 concurrency, SwiftPM plus iOS host, GUI/CLI startup separation, and local audio. |
| Verification and contract precision | 6/10 | Unit and lifecycle coverage, CLI byte fixtures/error precedence, and Apple runtime checks. |
| **Total** | **28/50** | Minimal scope with real platform and behavioral requirements. |

## stages

1. **Planning (this artifact):** specify product behavior, exact CLI contract, acceptance checks, scope, and complexity. Verdict is ready for implementation; no implementation files are owned by this stage.
2. **Implementation:** establish package targets and iOS host; build engine and CLI parser/renderer first; add AI, models, persistence, and tests; connect the four SwiftUI screens, animation, and sound. Keep dependency-free operation and shared rules throughout. Supply reproducible commands and an implementation handoff.
3. **Verification:** run Swift Testing, process-level CLI fixtures, macOS launch, iOS simulator build/launch, and focused manual flows/audio/accessibility checks. Record actual results and resolve failures within scope. Any unavoidable inability to satisfy acceptance must be explicit in the responsible stage's classified error log and blocked/escalate verdict.

The planning stage ends after writing and validating `.context/planning-0.md`. The next stage should implement this PRD; no commit or push is authorized by this contract.
