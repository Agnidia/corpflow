---
handoff:
  stage: AR
  verdict: ready
  worktask_id: live-codex-20261102T213202Z-5d14a20
  artifact: .context/architecture-0.md
  next_stage_focus: Implement the fixed SwiftPM boundaries and iOS host; prove engine and CLI contracts first, then persistence, cancellable game sessions, shared screens, and Apple-host integration.
---

# Tic-Tac-Toe architecture

## decisions

This design consumes `.context/planning-0.md`, including R1–R7 and AC1–AC8. The supplied stage contract and planning artifact establish the handoff format; no separate architecture template is present. This is a design artifact, with no implementation or test-execution claims.

**Choose MVVM with a main-actor, observable router.** SwiftUI renders observable state and sends user intents to view-models. `GameViewModel` owns one game session; `AppRouter` owns navigation and session lifetime. The pure engine alone decides legal moves and outcomes. This gives the four screens one navigation authority and makes cancellation and score recording testable without rendering views.

Use Swift tools version 6.0, Swift language mode 6, deployment targets `.macOS(.v15)` and `.iOS(.v18)`, and no package dependencies. SwiftUI, Observation, Foundation, AVFoundation, and Swift Testing come from Swift/Apple SDKs. Engine types need only the Swift standard library. No networking or external assets are required.

Fix the package boundaries as follows. Folders organize one library module; do not create additional production modules for this small app.

```text
Package.swift
Sources/
  TicTacToeKit/                 library product and target
    Engine/                    Board, Player, GameState, AIOpponent
    Models/                    GameSettings, Leaderboard, persisted values
    Services/                  local store, audio adapters, AI turn scheduler
    ViewModels/                AppRouter, GameViewModel, SettingsViewModel
    Views/                     root and exactly four shared SwiftUI screens
    CLI/                       pure argument parsing, simulation, byte rendering
  tictactoe/                   executable product and target; depends on kit
    main.swift                 pre-GUI dispatch and macOS composition only
Tests/
  TicTacToeKitTests/            Swift Testing; groups mirror library folders
  TicTacToeCLITests/            macOS process-level Swift Testing
iOSHost/                       minimal Xcode app; local package dependency
  TicTacToeIOSApp.swift         composition and shared root view only
```

`Engine` imports no UI, audio, persistence, or observation APIs. `Models` uses Foundation for Codable data and validation, with no SwiftUI dependency. `Services` implements injected ports; `ViewModels` composes the engine, models, and services; `Views` imports SwiftUI and consumes presentation state. The pure `CLI` adapter depends only on the engine and value types. Engine and models never depend on views or view-models. Kit may import Apple frameworks in presentation files: the *logic* is platform-independent, while compiling the complete library requires Apple SDKs. A Linux build is not a substitute for required platform validation.

The executable contains neither game rules nor persistence logic. A custom `@main`, `@MainActor` entry point examines arguments before constructing the SwiftUI `App`, router, sound adapter, or store. With zero user arguments it invokes the macOS SwiftUI app entry point; otherwise it executes the pure scripted command and exits. Keep the SwiftUI app declaration free of eager global service instances. Guard macOS executable startup with platform compilation conditions; the iOS host depends only on the library product and has its own `@main App`.

Expose only the shared root view, router/composition entry points, necessary injected protocols, and scripted-command interface publicly. Use `@testable import TicTacToeKit` for implementation-level unit tests. Do not expand the public API merely to inspect UI internals.

## trade-offs

| Choice | Benefit | Cost and decision |
| --- | --- | --- |
| One kit target with folder boundaries | Both hosts, CLI, and tests share rules without a framework hierarchy | Enforce import direction by review; extracting a separate engine package is unnecessary for nine cells. |
| `@Observable` reference models and `@MainActor` orchestration | Native SwiftUI tracking and serial state transitions under Swift 6 | Explicitly isolate services and task closures; do not assume observation supplies synchronization. |
| Enum-driven root navigation | Exactly four screens with centralized cleanup | No navigation stack or restoration; neither is required. |
| Synchronous minimax inside a scheduled main-actor turn | Deterministic, bounded work without sending mutable state between actors | Nine-cell search should remain small; measure on Apple hardware if responsiveness is questionable. No detached task is needed initially. |
| One versioned JSON store at an injected URL | Atomic settings/standings snapshots and simple isolated tests | Synchronous tiny reads/writes on the main actor are acceptable here; retain an error state if writes fail. |
| In-memory generated tone data through AVAudioPlayer | No downloads, asset pipeline, temporary audio files, or microphone permission | Audibility and interruptions require manual device/simulator checks. |
| Pure CLI adapter in kit | Exact parser/output tests without starting an application | A small non-UI adapter lives alongside reusable logic; entry-point I/O stays in the executable. |
| Thin Xcode iOS host | Produces the app bundle SwiftPM cannot produce alone | Maintain one small project/scheme with a relative local-package reference. |

Do not add repositories for individual entities, an event bus, a DI container, background services, Combine pipelines, or UI snapshot infrastructure. Explicit initializer injection is sufficient.

## patterns

**Engine as a value-state machine.** `Player` is X/O with an opponent property. `Board` owns exactly nine optional marks, exposes safe reads/empty indices, and restricts mutation to engine operations. Its initializer produces an empty board; callers cannot construct arbitrary invalid cell arrays. `GameState` contains the board, next player while active, and `GameResult` (`inProgress`, `win(player:line:)`, `draw`). A move returns an accepted transition or a typed rejection (`outOfRange`, `occupied`, `finished`); every rejection preserves the entire state. Detect a win before a draw and clear next player at termination. Winning lines are canonical index triples, covering three rows, three columns, and two diagonals.

`AIOpponent.chooseMove(in:difficulty:using:)` takes a state and an `inout` generic `RandomNumberGenerator`, and returns an optional legal index. It returns nil for terminal states. The GUI invokes it only on O's turn. Easy uses `Int.random(in:using:)` over sorted empty indices for uniform selection; avoid modulo reduction. Hard performs complete minimax, scoring AI wins +1, losses -1, draws 0. Traverse legal moves in ascending order and replace the best move only on a strictly better score, so equal outcomes choose the smallest index. No random consumption is needed for Hard and no heuristic depth cutoff is allowed.

**Single navigation owner.** Define:

```swift
enum AppScreen: Equatable { case mainMenu, game, leaderboard, settings }
enum GameMode: Equatable, Sendable { case local, versusAI }

@MainActor @Observable
final class AppRouter {
    private(set) var screen: AppScreen = .mainMenu
    private(set) var game: GameViewModel?
    var selectedMode: GameMode = .local
    // Inject shared settings, leaderboard/store, sound, RNG and scheduler factories.
    // startGame(), playAgain(), showLeaderboard(), showSettings(), showMainMenu()
}
```

The root holds its injected router in `@State`, switches on `screen`, and passes dependencies explicitly to child views; editable observable properties use `@Bindable`. Avoid a global singleton or four independent navigation booleans. `startGame` and `playAgain` invalidate any previous session, create a new view-model with a fresh session identity and current valid settings, then select `.game`. Leaving Game synchronously invalidates/cancels its work before discarding the view-model. Opening/leaving Settings creates/discards name drafts as required. Views cannot assign `screen` directly.

**Session-scoped game view-model.** `@MainActor @Observable GameViewModel` owns read-only engine state, mode, a snapshot of names/difficulty, a fresh session ID, active/inactive state, and a pending AI task. Task handles, services, RNG storage, and completion guards are observation-ignored implementation details. Expose derived board cells, current participant/status, winning line, and `canHumanPlay`; never duplicate engine outcome calculation in a view.

A human intent checks session activity, engine activity, and whose turn it is before calling the engine. An accepted move updates state and emits a move sound. A terminal transition immediately disables input, marks completion handled, records standings once, and then queues win/draw sound after the move sound. An accepted nonterminal X move in AI mode schedules precisely one O turn; a pending-task guard prevents duplicate scheduling. Local mode never schedules AI.

The pending task explicitly inherits `@MainActor`, awaits an injected scheduler, then checks cancellation, session identity/generation, active state, nonterminal state, and O's turn before computing/applying a move. It handles cancellation without state mutation. A cancellation-resistant test scheduler may still resume an obsolete task: identity and active-state checks must reject it. Clearing a task handle also checks its generation so stale cleanup cannot erase a newer task. `invalidate()` is synchronous and idempotent: mark inactive, advance generation, cancel/clear the task. SwiftUI appearance/disappearance and body evaluation must never be responsible for recording scores or starting AI turns.

**Exactly-once completion.** Set the view-model's completion guard before invoking synchronous leaderboard recording. The leaderboard service also tracks handled session IDs in memory, so duplicate completion calls cannot increment twice. Persist aggregate counters, not game history. Save failure keeps the already-applied in-memory totals and a visible nonfatal error; retry serializes the current snapshot without replaying the result mutation. Navigation away from an unfinished game does not invoke recording. A process restart cannot double-record a terminal session because unfinished/finished sessions themselves are never restored.

**Settings drafts and presentation.** `GameSettings` is a Codable value. `SettingsViewModel` holds editable name drafts and inline validation while `SettingsModel` holds last valid committed settings. Validate the two names together; commit them only when the pair is valid. Sound and difficulty changes can commit independently of invalid name drafts. Trim surrounding whitespace/newlines for names; reject empty names, duplicate normalized names, and normalized `Computer`. Define normalization as canonical Unicode normalization plus case folding using a fixed `en_US_POSIX` locale; retain diacritic distinctions. Do not use device-locale-sensitive equality/sorting. Leaving Settings discards invalid drafts.

Names and difficulty are captured at game creation; sound policy is shared live state. `Leaderboard` contains records keyed by stable participant ID. Display names are derived from committed settings, so renaming preserves scores. Sorting uses points descending, wins descending, normalized display-name UTF-8 lexicographic order ascending, then stable ID raw-value order. Filter out participants whose total games is zero.

**Shared native views.** Main Menu, Game, Leaderboard, and Settings are cross-platform SwiftUI views with native buttons/controls. A flexible square board and a scrollable surrounding layout handle phone portrait, tablet, and resized Mac windows. Draw the winning line through the centers obtained from board geometry, rather than fixed pixel offsets. Animate accepted placements from state changes, respecting `accessibilityReduceMotion`; outcome text and highlighted cells remain sufficient without animation. Cells expose row/column or index, mark/empty state, and disabled state. No UIKit/AppKit screen implementations or fifth screen are required. Nonfatal validation/save feedback appears inline within existing screens.

## integration-points

| Boundary | Injection and ownership | Production adapter / test substitute |
| --- | --- | --- |
| Randomness | `GameViewModel` owns RNG state; engine accepts `inout R: RandomNumberGenerator` | `SystemRandomNumberGenerator` / seeded deterministic generator; never call a hidden global random API in the engine. |
| Persistent storage | A single `@MainActor LocalStore` receives an absolute `storeURL`; models share this instance | Versioned JSON via Foundation / isolated file URL under the allowed workspace or in-memory store double. |
| Sound | `@MainActor protocol SoundPlaying { func play(_ effect: SoundEffect) }`; inject into router and game view-model | Platform audio adapter with a FIFO playback queue / recording spy or silent adapter. |
| AI timing | `@MainActor protocol AITurnScheduling { func waitForTurn() async throws }` | Cancelable short `Task.sleep` delay / manually released async scheduler without elapsed-time assumptions. |
| Session creation | Router creates a new identity for every game and passes it to the view-model | UUID or monotonic identity / fixed IDs for duplicate-record tests. |
| Process I/O | Pure `ScriptedCommand.run(arguments:) -> CommandResult` | Executable writes returned byte buffers once and exits / in-memory unit assertions plus subprocess tests. |

The store abstraction needs only load/current-state and narrow settings/result mutations; no general filesystem abstraction is necessary. Tests that exercise real persistence inject URLs explicitly. All application-controlled persistence, fixtures, test outputs, build artifacts, and generated project files for this worktask must remain under the permitted workdir. Never default to global UserDefaults, user Application Support, or an arbitrary temporary directory. Resolve the approved workspace root at the host composition boundary and inject a child URL such as `.tictactoe/state.json`; reject file URLs outside that root. The CLI receives no store at all. Use a workspace-local scratch directory for Apple build/test commands and caches where configurable.

The iOS host must supply a workspace root it can actually access under the applicable sandbox. Do not assume the repository's absolute macOS path is writable from an iOS app, or silently bypass the workdir restriction with a Documents fallback. Establish the allowed simulator workspace arrangement during host integration and report an explicit blocker if the available environment cannot provide it. This is a platform-verification dependency, not permission to write elsewhere.

`LocalStore` owns one observable in-memory snapshot shared by settings and leaderboard facades. Load once during GUI composition. Missing, invalid, or unsupported-version files return defaults; successful mutations encode a complete snapshot and atomically replace that same file. Validate decoded enum values, settings, participant keys, and nonnegative counters before adoption; use checked arithmetic for points/counter derivation so malformed extreme values cannot trap. Expose read/write failure state without crashing. Never delete an arbitrary corrupt file or let two independently loaded models overwrite each other's state.

The sound service uses four distinct synthesized PCM tones/envelopes: move, win, draw, and tap. Generate buffers in memory; retain players through completion. Shared playback policy checks current sound-enabled state, queues effects in invocation order, and stops/clears playback when disabled. Toggling sound off first disables playback and emits no tap. A terminal move queues move then outcome. Invalid/disabled board intents emit nothing; successful UI navigation/actions emit tap through the same policy. Use AVFoundation implementations behind platform guards, with iOS audio-session setup limited to the iOS adapter. Playback/setup failures are nonfatal and require no recording permission. Spy-based tests inspect semantic events and ordering without audio hardware.

Scripted dispatch accepts exactly `--moves` followed by one value; zero arguments selects GUI, and every other argument shape yields exit 2. Split the value on commas retaining empty tokens, trim ASCII space/tab only, skip empty tokens, and validate every remaining token before simulation. Require the entire token to match an optional sign followed by ASCII decimal digits and fit in Swift `Int`. Embedded newlines/whitespace, other characters, and overflow are parse errors. Negative and out-of-range integers parse successfully but fail as reached moves with exit 1.

After full parsing, apply alternating engine moves until termination; ignore later *integers* even if illegal as moves. Later malformed tokens already failed parsing with exit 2. Render only on success into a UTF-8 buffer: three rows with leading/trailing spaces, two exact separators, and `result: in_progress|X_wins|O_wins|draw`, all separated by LF with a final LF. A failure returns empty stdout and a nonempty stderr diagnostic. The executable writes no extra text and constructs no GUI/audio/store objects in this branch. CLI does not select mode, insert AI turns, or record scores.

**Swift Testing surface per target and folder:**

| Surface | Required behavioral coverage |
| --- | --- |
| Kit / Engine | Parameterize eight winning lines for both players using legal histories; alternation; draw; rejected occupied/out-of-range/post-terminal moves preserve the entire state; win precedes full-board draw. |
| Kit / AIOpponent | Easy legal choices with seeded RNG, terminal nil, injectable/reproducible draws from legal indices; Hard immediate win, forced block, lowest-index tie, terminal nil. Exhaustively branch over all legal human X replies while choosing deterministic Hard O responses and assert X never wins. Do not substitute a few games for this proof. |
| Kit / Models | Codable round trips, defaults, name trimming/normalization/reserved/duplicate validation, stable IDs across rename, empty standings, local/AI W/L/D accounting, shared computer record across difficulties, points and every sort tie-break. |
| Kit / Services | Fresh-instance restore from injected workspace file; missing/corrupt/unsupported/invalid data defaults; failed save retains memory and retry does not duplicate scores; composed settings/standings writes preserve one another. Audio event/disabled/queue policy tests use a spy playback sink; no hardware assumptions. |
| Kit / ViewModels | Main-actor tests for legal human intents, AI input lock, exactly one AI response, manual scheduler release, cancel/restart/navigation and cancellation-resistant stale completion. Verify terminal recording once, abandon records nothing, replay uses new settings/session, immediate sound policy, and event ordering. Router tests cover four destinations and cleanup; settings tests cover independent toggles and invalid draft discard. |
| Kit / CLI | Exact byte fixtures and parse-before-play precedence for every AC7/AC8 case, including actual newline, empty tokens, tabs, overflow, unsupported arguments, terminal trailing integers and terminal trailing malformed text. Failure buffers have empty stdout. |
| Executable / process tests | macOS `Foundation.Process` tests launch an explicitly supplied built `tictactoe` URL with arguments as separate strings; capture stdout/stderr/status and compare AC8 fixtures byte-for-byte. Include explicit empty argument versus omitted arguments; the no-argument GUI is a manual launch check. Verify scripted runs create/modify no files in an isolated workspace. |
| Shared Views and iOS host | Compile on both Apple targets, then manually verify four flows, native keyboard/accessibility behavior, placement animation, winning geometry, Reduce Motion, sound, resize/phone layout, and cross-launch persistence. No rendering unit tests required. |

Use `import Testing`, `@Test`, parameterized arguments, and `#expect`/`#require`. Keep injected temporary file roots unique per test, because Swift Testing may run tests in parallel. Actor-isolate UI tests explicitly; avoid XCTest and wall-clock sleeps. Build the executable before process tests; provide its path through test configuration rather than launching a nested package build or depending on test execution order. Process testing is macOS-only, not part of the iOS app target.

## schemas

Only settings and aggregate records persist. Engine, router, task handles, name drafts, session IDs, and current/terminal boards are transient.

```text
Player: X | O
Difficulty: easy | hard
ParticipantID: playerX | playerO | computer
GameMode: local | versusAI                  (transient)
SoundEffect: move | win | draw | tap         (transient)
Record: wins: Int, losses: Int, draws: Int  (nonnegative, bounded)
GameSettings: soundEnabled: Bool, difficulty: Difficulty,
              playerXName: String, playerOName: String
StoreEnvelope: schemaVersion: Int, settings: GameSettings,
               records: [String: Record]
```

```json
{
  "schemaVersion": 1,
  "settings": {
    "soundEnabled": true,
    "difficulty": "easy",
    "playerXName": "Player X",
    "playerOName": "Player O"
  },
  "records": {
    "playerX": { "wins": 0, "losses": 0, "draws": 0 },
    "playerO": { "wins": 0, "losses": 0, "draws": 0 },
    "computer": { "wins": 0, "losses": 0, "draws": 0 }
  }
}
```

Use explicit raw-value keys in the encoded records object rather than relying on Codable's representation for dictionaries with enum keys. Version 1 expects exactly these three participant IDs; unknown/malformed data uses safe defaults. Derived points (`3 * wins + draws`), games played, display names, and sort keys are not encoded. Treat unsupported versions as defaults without migration. A result maps local X/O to `playerX`/`playerO`, or AI X/O to `playerX`/`computer`; a winner adds one win and one loss, a draw adds one draw to each participant. The fixed Computer name is derived, never user-editable.

## open-questions

No unresolved product or module decision blocks implementation. The exact simulator/sandbox workspace arrangement and installed Apple toolchain availability must be established by the implementation/verification stage. They cannot be inferred from this architecture review. If the host cannot both honor the permitted write root and support required iOS persistence/build verification, record the actual environmental failure and escalate rather than weakening either requirement.

Tone pitches/durations, optional AI delay, and visual spacing are implementation choices within the PRD; they do not change module boundaries or acceptance. The handoff must provide exact macOS build/test/run and iOS simulator build/run commands and actual results. Architecture readiness does not assert that AC1–AC8 have passed.

## risks

| Risk | Mitigation and evidence required next |
| --- | --- |
| Swift 6 actor isolation or task cleanup race | Main-actor router/view-model/services; value engine; explicit task generation guards; compile in Swift 6 mode and drive stale scheduler continuations in tests. |
| Duplicate scores or lost settings | One shared snapshot owner, synchronous terminal guard plus session deduplication, atomic saves, retry persistence without replaying mutations; verify restored state and repeated callbacks. |
| CLI branch initializes GUI services or damages byte fidelity | Dispatch before composition, pure buffered command result, exact subprocess assertions including trailing spaces, no-file-side-effect checks. |
| iOS bundle/build or writable-root assumptions fail | Small local-package Xcode host; establish permitted sandbox storage and build/simulator access early; log actual blockers instead of claiming multiplatform delivery. |
| Host tools write caches outside the permitted workdir | Configure workspace-local build/test/cache paths before execution; do not run a verification command whose required writes cannot be kept within the allowed scope. |
| Hard AI correctness appears convincing without proof | Full minimax with stable iteration plus exhaustive exploration of every reachable human reply from the required initial position. |
| Audio effect order, muting, or platform lifecycle differs | Queue move before outcome, clear on disable, isolate platform setup, test policy with fakes, and check actual playback manually. |
| Visual correctness does not follow from unit tests | Manual Apple-host checks for board geometry, accessible status, keyboard controls, device sizes, and Reduce Motion remain required. |

This stage owns only `.context/architecture-0.md`; no source changes, commit, push, or runtime verification are performed here.
